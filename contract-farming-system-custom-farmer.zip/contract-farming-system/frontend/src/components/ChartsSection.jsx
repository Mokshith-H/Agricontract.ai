import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { BarChart3, PieChart as PieIcon } from 'lucide-react';

const STATUS_COLORS = {
  ACTIVE: '#10b981',
  AT_RISK: '#ef4444',
  DELAYED: '#f59e0b',
  COMPLETED: '#0284c7'
};

export default function ChartsSection({ cropYieldBreakdown, statusBreakdown }) {
  // Bar Chart Data Preparation
  const barData = (cropYieldBreakdown || []).map(item => ({
    crop: item.crop,
    Committed: Number(item.committedTons),
    Delivered: Number(item.deliveredTons),
    Rate: item.fulfillmentPercent
  }));

  // Donut Chart Data Preparation
  const pieData = Object.entries(statusBreakdown || {})
    .filter(([_, count]) => count > 0)
    .map(([status, count]) => ({
      name: status.replace('_', ' '),
      value: Number(count),
      rawStatus: status
    }));

  return (
    <div className="charts-grid">
      {/* 1. Bar Chart: Committed vs. Delivered Yield by Crop */}
      <div className="chart-card">
        <div className="card-header-flex">
          <div className="card-title">
            <BarChart3 size={18} color="#2d6a4f" />
            <span>Yield Reconciliation by Crop (Committed vs. Procured Tons)</span>
          </div>
        </div>
        <div style={{ width: '100%', height: 290 }}>
          <ResponsiveContainer>
            <BarChart data={barData} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="crop" stroke="#64748b" fontSize={12} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={12} tickLine={false} unit=" T" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #cbd5e1', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}
                formatter={(value) => [`${value} Tons`, '']}
              />
              <Legend wrapperStyle={{ paddingTop: '8px', fontSize: '12px' }} />
              <Bar dataKey="Committed" fill="#94a3b8" radius={[4, 4, 0, 0]} name="Expected Target" />
              <Bar dataKey="Delivered" fill="#10b981" radius={[4, 4, 0, 0]} name="Delivered Harvest" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 2. Donut Chart: Contract Health Breakdown */}
      <div className="chart-card">
        <div className="card-header-flex">
          <div className="card-title">
            <PieIcon size={18} color="#2d6a4f" />
            <span>Contract Health Portfolio</span>
          </div>
        </div>
        <div style={{ width: '100%', height: 230 }}>
          <ResponsiveContainer>
            <PieChart>
              <Pie
                data={pieData}
                innerRadius={55}
                outerRadius={85}
                paddingAngle={4}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={STATUS_COLORS[entry.rawStatus] || '#64748b'} 
                  />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value, name) => [`${value} Contracts`, name]}
                contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', justifyContent: 'center', marginTop: '6px' }}>
          {pieData.map(item => (
            <span key={item.name} style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', fontSize: '0.78rem', fontWeight: 600 }}>
              <span style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: STATUS_COLORS[item.rawStatus] }} />
              {item.name} ({item.value})
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
