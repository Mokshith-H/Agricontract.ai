import React, { useState } from 'react';
import { Search, Eye, AlertTriangle, ShieldCheck, CheckCircle2, Sprout } from 'lucide-react';

export default function ContractsTable({ contracts, onSelectContract, onNewContract }) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('ALL');

  const filteredContracts = (contracts || []).filter(c => {
    const matchesFilter = filter === 'ALL' || c.status === filter;
    const query = search.toLowerCase();
    const matchesSearch = 
      c.contractCode?.toLowerCase().includes(query) ||
      c.cropType?.toLowerCase().includes(query) ||
      c.variety?.toLowerCase().includes(query) ||
      c.farmer?.name?.toLowerCase().includes(query) ||
      c.farmer?.village?.toLowerCase().includes(query);
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="table-card">
      <div className="table-toolbar">
        <div className="search-box">
          <Search size={16} className="search-icon" />
          <input 
            type="text" 
            placeholder="Search crop, farmer, contract code..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-pills">
          {['ALL', 'ACTIVE', 'AT_RISK', 'DELAYED', 'COMPLETED'].map(f => (
            <button
              key={f}
              className={`filter-btn ${filter === f ? 'active' : ''}`}
              onClick={() => setFilter(f)}
            >
              {f.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table className="custom-table">
          <thead>
            <tr>
              <th>Contract Code</th>
              <th>Farmer & Location</th>
              <th>Crop / Variety</th>
              <th>Committed Acreage</th>
              <th>Expected Yield</th>
              <th>Price / Ton</th>
              <th>Harvest Window</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredContracts.length === 0 ? (
              <tr>
                <td colSpan="9" style={{ textAlign: 'center', padding: '36px', color: '#94a3b8' }}>
                  No contracts matched your search or filter.
                </td>
              </tr>
            ) : (
              filteredContracts.map(c => (
                <tr key={c.id}>
                  <td>
                    <span className="contract-code-cell">
                      <Sprout size={14} color="#2d6a4f" />
                      {c.contractCode}
                    </span>
                  </td>
                  <td>
                    <div className="farmer-cell">
                      <span className="farmer-name">{c.farmer?.name}</span>
                      <span className="farmer-location">{c.farmer?.village}, {c.farmer?.district}</span>
                    </div>
                  </td>
                  <td>
                    <div>
                      <span className="crop-tag">{c.cropType}</span>
                      <div style={{ fontSize: '0.74rem', color: '#64748b', marginTop: '2px' }}>{c.variety}</div>
                    </div>
                  </td>
                  <td><strong>{c.committedAcreage}</strong> Acres</td>
                  <td><strong>{c.expectedYieldTons}</strong> Tons</td>
                  <td>${Number(c.pricePerTon).toLocaleString()}</td>
                  <td style={{ fontSize: '0.8rem', color: '#475569' }}>
                    {c.expectedHarvestDate}
                  </td>
                  <td>
                    <span className={`badge badge-${c.status?.toLowerCase()}`}>
                      {c.status === 'AT_RISK' && <AlertTriangle size={11} />}
                      {c.status?.replace('_', ' ')}
                    </span>
                  </td>
                  <td>
                    <button 
                      className="btn btn-outline btn-sm"
                      onClick={() => onSelectContract(c.id)}
                      title="Inspect contract lifecycle, advisory logs & milestones"
                    >
                      <Eye size={14} />
                      <span>Details</span>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
