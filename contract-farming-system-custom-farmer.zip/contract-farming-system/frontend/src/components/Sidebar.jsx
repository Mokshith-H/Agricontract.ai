import React from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  CalendarCheck, 
  Truck, 
  Bot, 
  Sprout, 
  ShieldCheck 
} from 'lucide-react';

export default function Sidebar({ currentTab, setCurrentTab, atRiskCount, pendingPaymentsCount }) {
  const navItems = [
    { id: 'dashboard', label: 'Progress Dashboard', icon: LayoutDashboard },
    { id: 'contracts', label: 'Contracts & Lifecycle', icon: FileText, badge: atRiskCount > 0 ? `${atRiskCount} Risk` : null },
    { id: 'visits', label: 'Field Visits & Advisory', icon: CalendarCheck },
    { id: 'procurement', label: 'Procurement & Payouts', icon: Truck, badge: pendingPaymentsCount > 0 ? `${pendingPaymentsCount} Due` : null },
    { id: 'copilot', label: 'Agentic AI Copilot', icon: Bot, isSpecial: true }
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-brand-icon">
          <Sprout size={22} />
        </div>
        <div>
          <div className="brand-title">AgriContract AI</div>
          <div className="brand-subtitle">Farmer Relations OS</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              className={`nav-link ${isActive ? 'active' : ''}`}
              onClick={() => setCurrentTab(item.id)}
            >
              <Icon size={18} />
              <span>{item.label}</span>
              {item.badge && <span className="nav-badge">{item.badge}</span>}
            </button>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="ai-engine-tag">
          <div className="status-dot"></div>
          <div>
            <div style={{ fontWeight: 700, fontSize: '0.8rem' }}>Agentic Engine Active</div>
            <div style={{ fontSize: '0.7rem', opacity: 0.85 }}>Autonomous Risk & Payouts</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
