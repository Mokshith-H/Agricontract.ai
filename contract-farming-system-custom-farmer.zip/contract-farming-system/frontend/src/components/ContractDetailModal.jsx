import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  CalendarCheck, 
  Truck, 
  DollarSign, 
  ShieldAlert, 
  Clock, 
  Sprout, 
  User, 
  Bot, 
  RefreshCw 
} from 'lucide-react';

export default function ContractDetailModal({ 
  contractDetails, 
  isLoading, 
  error, 
  onClose, 
  onRetry 
}) {
  const [activeTab, setActiveTab] = useState('overview');
  const closeButtonRef = useRef(null);

  // Keyboard Escape listener
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Auto-focus close button for keyboard accessibility
  useEffect(() => {
    if (closeButtonRef.current) {
      closeButtonRef.current.focus();
    }
  }, [isLoading, contractDetails]);

  const stages = [
    { num: 1, label: 'Contract Signed' },
    { num: 2, label: 'Sowing Verified' },
    { num: 3, label: 'Advisory Compliant' },
    { num: 4, label: 'Harvest Delivered' },
    { num: 5, label: 'Payment Settled' }
  ];

  const currentStage = contractDetails?.lifecycleStage || 1;

  return (
    <div className="modal-backdrop" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="modal-contract-title">
      <div className="modal-dialog" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="modal-header">
          <div className="modal-title" id="modal-contract-title">
            <Sprout size={24} color="#2d6a4f" />
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span>{contractDetails?.contractCode || 'Contract Details'}</span>
                {contractDetails?.status && (
                  <span className={`badge badge-${contractDetails.status?.toLowerCase()}`}>
                    {contractDetails.status}
                  </span>
                )}
              </div>
              <div style={{ fontSize: '0.78rem', color: '#64748b', fontWeight: 500 }}>
                {contractDetails ? `${contractDetails.cropType} (${contractDetails.variety}) — Farmer: ${contractDetails.farmerName}` : 'Loading contract information...'}
              </div>
            </div>
          </div>
          <button 
            ref={closeButtonRef}
            className="close-btn" 
            onClick={onClose}
            aria-label="Close contract details modal (Escape)"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="modal-body">
          {isLoading && (
            <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
              <div className="spinner" style={{ width: 32, height: 32, borderTopColor: '#2d6a4f', margin: '0 auto 16px auto' }}></div>
              <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Fetching complete contract lifecycle and compliance logs...</div>
            </div>
          )}

          {error && !isLoading && (
            <div style={{ textAlign: 'center', padding: '40px 20px' }}>
              <div style={{ width: 48, height: 48, borderRadius: '50%', background: '#fee2e2', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px auto' }}>
                <AlertTriangle size={24} color="#dc2626" />
              </div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#991b1b', marginBottom: '8px' }}>Failed to Load Contract Details</h3>
              <p style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '16px' }}>{error}</p>
              <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
                {onRetry && (
                  <button className="btn btn-primary btn-sm" onClick={onRetry}>
                    <RefreshCw size={14} /> Retry Fetch
                  </button>
                )}
                <button className="btn btn-outline btn-sm" onClick={onClose}>Close</button>
              </div>
            </div>
          )}

          {!isLoading && !error && contractDetails && (
            <>
              {/* 5-Stage Visual Stepper */}
              <div style={{ background: '#f8faf8', padding: '16px 20px', borderRadius: '12px', border: '1px solid #e2e8f0', marginBottom: '22px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#2d6a4f', textTransform: 'uppercase' }}>
                    Contract Lifecycle Progress: {contractDetails.lifecycleStageName}
                  </span>
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#64748b' }}>
                    Stage {currentStage} of 5
                  </span>
                </div>

                <div className="stepper-container">
                  <div className="stepper-line">
                    <div 
                      className="stepper-progress" 
                      style={{ width: `${((currentStage - 1) / (stages.length - 1)) * 100}%` }}
                    />
                  </div>

                  {stages.map((st) => {
                    const isCompleted = st.num < currentStage || (currentStage === 5 && st.num === 5);
                    const isActive = st.num === currentStage && currentStage !== 5;
                    return (
                      <div 
                        key={st.num} 
                        className={`step-node ${isCompleted ? 'completed' : ''} ${isActive ? 'active' : ''}`}
                      >
                        <div className="step-circle">
                          {isCompleted ? <CheckCircle2 size={18} /> : st.num}
                        </div>
                        <span className="step-label">{st.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* AI Risk & Diagnostic Banner */}
              <div style={{ 
                backgroundColor: contractDetails.status === 'AT_RISK' ? '#fff5f5' : '#f0fdf4',
                border: `1px solid ${contractDetails.status === 'AT_RISK' ? '#fecaca' : '#bbf7d0'}`,
                padding: '12px 16px',
                borderRadius: '10px',
                marginBottom: '20px',
                display: 'flex',
                alignItems: 'flex-start',
                gap: '12px'
              }}>
                {contractDetails.status === 'AT_RISK' ? (
                  <AlertTriangle size={20} color="#dc2626" style={{ flexShrink: 0, marginTop: '2px' }} />
                ) : (
                  <ShieldAlert size={20} color="#16a34a" style={{ flexShrink: 0, marginTop: '2px' }} />
                )}
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.85rem', color: contractDetails.status === 'AT_RISK' ? '#991b1b' : '#166534' }}>
                    Agentic AI Compliance Diagnostic:
                  </div>
                  <div style={{ fontSize: '0.82rem', color: '#334155', marginTop: '2px' }}>
                    {contractDetails.aiRiskNotes}
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <div className="modal-tabs">
                <button 
                  className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
                  onClick={() => setActiveTab('overview')}
                >
                  Overview & Economics
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'advisories' ? 'active' : ''}`}
                  onClick={() => setActiveTab('advisories')}
                >
                  Advisories ({contractDetails.advisoryLogs?.length || 0})
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'visits' ? 'active' : ''}`}
                  onClick={() => setActiveTab('visits')}
                >
                  Field Visits ({contractDetails.fieldVisits?.length || 0})
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'procurement' ? 'active' : ''}`}
                  onClick={() => setActiveTab('procurement')}
                >
                  Deliveries ({contractDetails.procurementRecords?.length || 0})
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'milestones' ? 'active' : ''}`}
                  onClick={() => setActiveTab('milestones')}
                >
                  Milestones ({contractDetails.paymentMilestones?.length || 0})
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'logs' ? 'active' : ''}`}
                  onClick={() => setActiveTab('logs')}
                >
                  AI Agent Logs ({contractDetails.agentLogs?.length || 0})
                </button>
              </div>

              {/* Tab 1: Overview */}
              {activeTab === 'overview' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                  <div style={{ background: '#fafbfa', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0' }}>
                    <h4 style={{ fontSize: '0.88rem', fontWeight: 700, marginBottom: '12px', color: '#1b4332' }}>
                      Farmer Information
                    </h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.84rem' }}>
                      <div><strong>Name:</strong> {contractDetails.farmerName}</div>
                      <div><strong>Phone:</strong> {contractDetails.farmerPhone}</div>
                      <div><strong>Village & District:</strong> {contractDetails.farmerVillage}, {contractDetails.farmerDistrict}</div>
                      <div><strong>KYC Status:</strong> {contractDetails.kycVerified ? 'Verified & Onboarded' : 'Pending Verification'}</div>
                    </div>
                  </div>

                  <div style={{ background: '#fafbfa', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0' }}>
                    <h4 style={{ fontSize: '0.88rem', fontWeight: 700, marginBottom: '12px', color: '#1b4332' }}>
                      Contract Economics
                    </h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.84rem' }}>
                      <div><strong>Committed Acreage:</strong> {contractDetails.committedAcreage} Acres</div>
                      <div><strong>Expected Yield:</strong> {contractDetails.expectedYieldTons} Tons</div>
                      <div><strong>Delivered to Date:</strong> {contractDetails.deliveredYieldTons} Tons</div>
                      <div><strong>Price per Ton:</strong> ${Number(contractDetails.pricePerTon).toLocaleString()}</div>
                      <div><strong>Total Contract Value:</strong> ${Number(contractDetails.totalContractValue).toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Sowing & Agronomic Advisories */}
              {activeTab === 'advisories' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {(!contractDetails.advisoryLogs || contractDetails.advisoryLogs.length === 0) ? (
                    <div style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No advisories logged for this contract.</div>
                  ) : (
                    contractDetails.advisoryLogs.map((adv) => (
                      <div key={adv.id} style={{ padding: '12px', background: '#fafbfa', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                          <span style={{ fontWeight: 700, fontSize: '0.85rem', color: '#2d6a4f' }}>
                            Stage: {adv.stage}
                          </span>
                          <span className={`badge badge-${adv.complianceStatus?.toLowerCase()}`}>
                            {adv.complianceStatus}
                          </span>
                        </div>
                        <p style={{ fontSize: '0.82rem', color: '#334155', marginBottom: '6px' }}>{adv.advisoryText}</p>
                        <div style={{ fontSize: '0.74rem', color: '#64748b' }}>
                          Scheduled: {adv.scheduledDate} {adv.actualDate && `| Completed: ${adv.actualDate}`}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 3: Field Visits */}
              {activeTab === 'visits' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {(!contractDetails.fieldVisits || contractDetails.fieldVisits.length === 0) ? (
                    <div style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No field visits logged for this contract yet.</div>
                  ) : (
                    contractDetails.fieldVisits.map((v) => (
                      <div key={v.id} style={{ padding: '12px', background: '#fafbfa', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                          <span style={{ fontWeight: 700, fontSize: '0.85rem' }}>Officer: {v.officerName}</span>
                          <div style={{ display: 'flex', gap: '6px' }}>
                            <span className={`badge ${v.cropHealthScore >= 7 ? 'badge-active' : 'badge-at_risk'}`}>
                              Health Score: {v.cropHealthScore}/10
                            </span>
                            {v.pestAlert && (
                              <span className="badge badge-at_risk">
                                <AlertTriangle size={12} /> Pest Alert
                              </span>
                            )}
                          </div>
                        </div>
                        <div style={{ fontSize: '0.8rem', color: '#475569', marginBottom: '4px' }}>
                          <strong>Soil Moisture:</strong> {v.soilMoisture} | <strong>Date:</strong> {v.visitDate}
                        </div>
                        <p style={{ fontSize: '0.82rem', color: '#1e293b' }}>{v.remarks}</p>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 4: Deliveries */}
              {activeTab === 'procurement' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {(!contractDetails.procurementRecords || contractDetails.procurementRecords.length === 0) ? (
                    <div style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No deliveries logged yet for this contract.</div>
                  ) : (
                    contractDetails.procurementRecords.map((p) => (
                      <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', background: '#fafbfa', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: '0.85rem' }}>Receipt: {p.receiptNumber}</div>
                          <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Delivery Date: {p.deliveryDate}</div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontSize: '1rem', fontWeight: 800, color: '#15803d' }}>
                            {p.deliveredTons} Tons {p.payoutAmount ? `($${Number(p.payoutAmount).toLocaleString()})` : ''}
                          </div>
                          <span className="badge badge-completed">{p.qualityGrade}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 5: Payment Milestones */}
              {activeTab === 'milestones' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {(!contractDetails.paymentMilestones || contractDetails.paymentMilestones.length === 0) ? (
                    <div style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No payment milestones configured yet.</div>
                  ) : (
                    contractDetails.paymentMilestones.map((m) => (
                      <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', background: '#fafbfa', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: '0.85rem' }}>{m.milestoneTitle}</div>
                          <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Condition: {m.triggerCondition}</div>
                        </div>
                        <div style={{ textAlign: 'right', display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span style={{ fontSize: '1.05rem', fontWeight: 800, color: '#1e293b' }}>
                            ${Number(m.amount).toLocaleString()}
                          </span>
                          <span className={`badge badge-${m.status?.toLowerCase()}`}>
                            {m.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 6: AI Agent Logs */}
              {activeTab === 'logs' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {(!contractDetails.agentLogs || contractDetails.agentLogs.length === 0) ? (
                    <div style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>
                      No contract-specific agent audit entries recorded yet.
                    </div>
                  ) : (
                    contractDetails.agentLogs.map((l) => (
                      <div key={l.id} style={{ padding: '12px', background: '#fafbfa', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <Bot size={15} color="#2d6a4f" />
                            <span style={{ fontWeight: 700, fontSize: '0.84rem', color: '#1b4332' }}>{l.agentName}</span>
                            <span className="timeline-code-pill">{l.actionType}</span>
                          </div>
                          <span style={{ fontSize: '0.72rem', color: '#64748b' }}>{l.timestamp}</span>
                        </div>
                        <p style={{ fontSize: '0.82rem', color: '#334155' }}>{l.reasoning}</p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="modal-footer">
          <button className="btn btn-primary" onClick={onClose}>
            Close (Esc)
          </button>
        </div>
      </div>
    </div>
  );
}
