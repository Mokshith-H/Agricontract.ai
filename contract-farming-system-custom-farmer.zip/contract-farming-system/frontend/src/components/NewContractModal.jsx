import React, { useState, useEffect, useRef } from 'react';
import { X, Sprout, Check, UserPlus } from 'lucide-react';
import { fetchFarmers, createFarmer, createContract } from '../api';

export default function NewContractModal({ isOpen, onClose, onSuccess }) {
  const [farmers, setFarmers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [addNewFarmer, setAddNewFarmer] = useState(false);
  const [newFarmer, setNewFarmer] = useState({ name: '', state: '', acreage: '10', phone: '' });
  const firstInputRef = useRef(null);

  const [formData, setFormData] = useState({
    farmerId: '',
    cropType: 'Wheat',
    variety: 'Sharbati Premium',
    committedAcreage: 10,
    expectedYieldTons: 20,
    pricePerTon: 320,
    sowingStartDate: new Date().toISOString().split('T')[0],
    sowingEndDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
    expectedHarvestDate: new Date(Date.now() + 90 * 86400000).toISOString().split('T')[0]
  });

  // Escape key listener to close
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Auto-focus first input upon open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        if (firstInputRef.current) firstInputRef.current.focus();
      }, 50);

      fetchFarmers()
        .then(res => {
          setFarmers(res.data || []);
          if (res.data?.length > 0 && !formData.farmerId) {
            setFormData(prev => ({ ...prev, farmerId: res.data[0].id }));
          }
        })
        .catch(err => console.error(err));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const totalContractVal = (Number(formData.expectedYieldTons) || 0) * (Number(formData.pricePerTon) || 0);
  const m1 = totalContractVal * 0.20;
  const m2 = totalContractVal * 0.30;
  const m3 = totalContractVal * 0.50;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      let farmerId = Number(formData.farmerId);

      if (addNewFarmer) {
        if (!newFarmer.name.trim() || !newFarmer.state.trim()) {
          throw new Error('Enter the farmer name and state.');
        }
        const farmerResponse = await createFarmer({
          name: newFarmer.name.trim(),
          state: newFarmer.state.trim(),
          district: newFarmer.state.trim(),
          village: newFarmer.state.trim(),
          phone: newFarmer.phone.trim() || 'Not provided',
          totalAcreage: Number(newFarmer.acreage),
          kycVerified: false
        });
        farmerId = farmerResponse.data.id;
      }

      await createContract({
        ...formData,
        farmerId,
        committedAcreage: Number(formData.committedAcreage),
        expectedYieldTons: Number(formData.expectedYieldTons),
        pricePerTon: Number(formData.pricePerTon)
      });
      setLoading(false);
      onSuccess();
      onClose();
    } catch (err) {
      setLoading(false);
      setError(err.response?.data?.message || err.message || 'Failed to create contract. Verify inputs.');
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="new-contract-modal-title">
      <div className="modal-dialog" style={{ maxWidth: 640 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title" id="new-contract-modal-title">
            <Sprout size={22} color="#2d6a4f" />
            <span>Onboard New Farmer Contract</span>
          </div>
          <button className="close-btn" onClick={onClose} aria-label="Close modal"><X size={18} /></button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && (
              <div style={{ padding: '10px 14px', background: '#fee2e2', color: '#b91c1c', borderRadius: '8px', marginBottom: '16px', fontSize: '0.84rem' }}>
                {error}
              </div>
            )}

            <div className="form-group">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginBottom: 8 }}>
                <label className="form-label" htmlFor={addNewFarmer ? 'new-farmer-name' : 'new-farmer-select'} style={{ marginBottom: 0 }}>Contracted Farmer</label>
                <button type="button" className="btn btn-outline" style={{ padding: '7px 11px', fontSize: '0.8rem' }} onClick={() => setAddNewFarmer(v => !v)}>
                  <UserPlus size={15} /> {addNewFarmer ? 'Choose Existing Farmer' : 'Add New Farmer'}
                </button>
              </div>
              {addNewFarmer ? (
                <>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label" htmlFor="new-farmer-name">Farmer Name</label>
                      <input id="new-farmer-name" ref={firstInputRef} type="text" className="form-control" placeholder="Enter farmer full name" value={newFarmer.name} onChange={e => setNewFarmer({ ...newFarmer, name: e.target.value })} required />
                    </div>
                    <div className="form-group">
                      <label className="form-label" htmlFor="new-farmer-state">State</label>
                      <input id="new-farmer-state" type="text" className="form-control" placeholder="e.g. Punjab, Maharashtra" value={newFarmer.state} onChange={e => setNewFarmer({ ...newFarmer, state: e.target.value })} required />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label" htmlFor="new-farmer-acres">Farmland Size (Acres)</label>
                      <input id="new-farmer-acres" type="number" min="0.1" step="0.1" className="form-control" value={newFarmer.acreage} onChange={e => { setNewFarmer({ ...newFarmer, acreage: e.target.value }); setFormData(prev => ({ ...prev, committedAcreage: e.target.value })); }} required />
                    </div>
                    <div className="form-group">
                      <label className="form-label" htmlFor="new-farmer-phone">Phone (Optional)</label>
                      <input id="new-farmer-phone" type="tel" className="form-control" placeholder="Farmer phone number" value={newFarmer.phone} onChange={e => setNewFarmer({ ...newFarmer, phone: e.target.value })} />
                    </div>
                  </div>
                </>
              ) : (
                <select id="new-farmer-select" ref={firstInputRef} className="form-control" value={formData.farmerId} onChange={(e) => setFormData({ ...formData, farmerId: e.target.value })} required>
                  <option value="" disabled>Select an existing farmer</option>
                  {farmers.map(f => <option key={f.id} value={f.id}>{f.name} — {f.village}, {f.state || f.district} ({f.totalAcreage} Acres)</option>)}
                </select>
              )}
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label" htmlFor="new-crop-type">Crop Type</label>
                <select 
                  id="new-crop-type"
                  className="form-control"
                  value={formData.cropType}
                  onChange={(e) => setFormData({ ...formData, cropType: e.target.value })}
                >
                  <option value="Wheat">Wheat</option>
                  <option value="Basmati Rice">Basmati Rice</option>
                  <option value="Tomato">Tomato</option>
                  <option value="Cotton">Cotton</option>
                  <option value="Soybean">Soybean</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="new-crop-variety">Variety / Hybrid</label>
                <input 
                  id="new-crop-variety"
                  type="text" 
                  className="form-control"
                  value={formData.variety}
                  onChange={(e) => setFormData({ ...formData, variety: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label" htmlFor="new-acreage">Committed Acreage (Acres)</label>
                <input 
                  id="new-acreage"
                  type="number" 
                  step="0.5" 
                  className="form-control"
                  value={formData.committedAcreage}
                  onChange={(e) => setFormData({ ...formData, committedAcreage: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="new-yield">Expected Yield (Tons)</label>
                <input 
                  id="new-yield"
                  type="number" 
                  step="0.5" 
                  className="form-control"
                  value={formData.expectedYieldTons}
                  onChange={(e) => setFormData({ ...formData, expectedYieldTons: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="new-price">Agreed Minimum Support Price (₹ / Ton)</label>
              <input 
                id="new-price"
                type="number" 
                step="5" 
                className="form-control"
                value={formData.pricePerTon}
                onChange={(e) => setFormData({ ...formData, pricePerTon: e.target.value })}
                required
              />
            </div>

            {/* Live Milestone Calculations Preview */}
            <div style={{ background: '#f8faf8', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px 16px', marginBottom: '16px' }}>
              <div style={{ fontSize: '0.8rem', fontWeight: 700, color: '#1b4332', marginBottom: '6px' }}>
                Total Contract Value: ₹{totalContractVal.toLocaleString('en-IN')}
              </div>
              <div style={{ fontSize: '0.75rem', color: '#64748b', display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
                <span>Stage 1 Mobilization (20%): <strong>₹{m1.toLocaleString('en-IN')}</strong></span>
                <span>Stage 2 Mid-Growth (30%): <strong>₹{m2.toLocaleString('en-IN')}</strong></span>
                <span>Stage 3 Final Harvest (50%): <strong>₹{m3.toLocaleString('en-IN')}</strong></span>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label" htmlFor="new-sowing-start">Sowing Start Date</label>
                <input 
                  id="new-sowing-start"
                  type="date" 
                  className="form-control"
                  value={formData.sowingStartDate}
                  onChange={(e) => setFormData({ ...formData, sowingStartDate: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="new-sowing-end">Sowing End Date</label>
                <input 
                  id="new-sowing-end"
                  type="date" 
                  className="form-control"
                  value={formData.sowingEndDate}
                  onChange={(e) => setFormData({ ...formData, sowingEndDate: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="new-harvest-date">Expected Harvest Delivery Date</label>
              <input 
                id="new-harvest-date"
                type="date" 
                className="form-control"
                value={formData.expectedHarvestDate}
                onChange={(e) => setFormData({ ...formData, expectedHarvestDate: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-outline" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <div className="spinner"></div> : <Check size={16} />}
              <span>Onboard & Initialize Contract</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
