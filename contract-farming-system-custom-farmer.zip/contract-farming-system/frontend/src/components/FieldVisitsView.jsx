import React, { useState, useEffect, useRef } from 'react';
import { 
  CalendarCheck, 
  PlusCircle, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  Sprout, 
  ChevronDown, 
  ChevronUp 
} from 'lucide-react';
import { fetchFieldVisits, recordFieldVisit, fetchContracts } from '../api';

export default function FieldVisitsView({ onActionComplete }) {
  const [visits, setVisits] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [notification, setNotification] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(true);
  const firstInputRef = useRef(null);

  const [form, setForm] = useState({
    contractId: '',
    officerName: 'Dr. Alok Verma',
    visitDate: new Date().toISOString().split('T')[0],
    cropHealthScore: 8,
    pestAlert: false,
    soilMoisture: 'Optimal (22%)',
    remarks: 'Field inspection completed. Crop vegetative vigor in healthy condition.'
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [vRes, cRes] = await Promise.all([fetchFieldVisits(), fetchContracts()]);
      setVisits(vRes.data || []);
      setContracts(cRes.data || []);
      if (cRes.data?.length > 0 && !form.contractId) {
        setForm(prev => ({ ...prev, contractId: cRes.data[0].id }));
      }
    } catch (e) {
      console.error('Error loading field visits:', e);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.contractId) {
      alert('Please select a contract.');
      return;
    }
    setSubmitting(true);
    try {
      await recordFieldVisit({
        ...form,
        contractId: Number(form.contractId),
        cropHealthScore: Number(form.cropHealthScore)
      });
      setSubmitting(false);
      setNotification('Field visit logged successfully! Autonomous AI Compliance Agent evaluated crop vigor & pest alerts.');
      setTimeout(() => setNotification(''), 5500);
      // Reset form remarks but keep officer/date
      setForm(prev => ({
        ...prev,
        remarks: 'Vegetative vigor monitored. Agronomic advisory compliance verified.',
        cropHealthScore: 8,
        pestAlert: false
      }));
      await loadData();
      if (onActionComplete) onActionComplete();
    } catch (err) {
      setSubmitting(false);
      alert('Failed to log field visit. Please verify inputs.');
    }
  };

  const selectedContract = contracts.find(c => String(c.id) === String(form.contractId));

  return (
    <div>
      {notification && (
        <div className="toast-bar" style={{ position: 'relative', bottom: 'auto', right: 'auto', marginBottom: '20px', background: '#064e3b', border: '1px solid #059669' }}>
          <Sparkles size={18} color="#34d399" />
          <span>{notification}</span>
        </div>
      )}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
        <div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#1b4332' }}>
            Field Agronomic Visits & Health Monitoring
          </h2>
          <p style={{ fontSize: '0.83rem', color: '#64748b' }}>
            Real-time field officer observations. Any visit with Crop Health Score &lt; 6 or Pest Alert triggers immediate AI risk escalation.
          </p>
        </div>
        <button 
          type="button"
          className="btn btn-primary"
          onClick={() => {
            setIsFormOpen(!isFormOpen);
            setTimeout(() => firstInputRef.current?.focus(), 100);
          }}
          aria-expanded={isFormOpen}
        >
          {isFormOpen ? <ChevronUp size={16} /> : <PlusCircle size={16} />}
          <span>{isFormOpen ? 'Hide Entry Form' : 'Log New Field Visit'}</span>
        </button>
      </div>

      {/* Interactive Form Card (Accessible & Typable) */}
      {isFormOpen && (
        <div className="table-card" style={{ padding: '24px', marginBottom: '26px', border: '2px solid #52b788', background: '#ffffff' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '18px' }}>
            <CalendarCheck size={20} color="#2d6a4f" />
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: '#1b4332' }}>
              Log Field Agronomic Inspection
            </h3>
            <span style={{ fontSize: '0.75rem', background: '#e8f5e9', color: '#2d6a4f', padding: '2px 8px', borderRadius: '12px', fontWeight: 700 }}>
              AI Compliance Active
            </span>
          </div>

          <form onSubmit={handleSubmit} id="field-visit-form">
            <div className="form-row">
              <div className="form-group">
                <label className="form-label" htmlFor="fv-contract-select">Target Contract</label>
                <select 
                  id="fv-contract-select"
                  ref={firstInputRef}
                  className="form-control"
                  value={form.contractId}
                  onChange={(e) => setForm({ ...form, contractId: e.target.value })}
                  required
                >
                  {contracts.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.contractCode} — {c.farmer?.name} ({c.cropType}, {c.committedAcreage} Acres)
                    </option>
                  ))}
                </select>
                {selectedContract && (
                  <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '4px' }}>
                    Farmer: <strong>{selectedContract.farmer?.name}</strong> | Village: {selectedContract.farmer?.village} | Current Status: <strong style={{ color: selectedContract.status === 'AT_RISK' ? '#dc2626' : '#16a34a' }}>{selectedContract.status}</strong>
                  </div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="fv-officer-name">Field Officer Name</label>
                <input 
                  id="fv-officer-name"
                  type="text" 
                  className="form-control"
                  value={form.officerName}
                  onChange={(e) => setForm({ ...form, officerName: e.target.value })}
                  placeholder="e.g. Dr. Alok Verma, Priya Sharma"
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label" htmlFor="fv-visit-date">Inspection Date</label>
                <input 
                  id="fv-visit-date"
                  type="date" 
                  className="form-control"
                  value={form.visitDate}
                  onChange={(e) => setForm({ ...form, visitDate: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="fv-crop-health">Crop Health Score (1–10)</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <input 
                    id="fv-crop-health"
                    type="number" 
                    min="1" 
                    max="10" 
                    className="form-control"
                    style={{ maxWidth: '120px' }}
                    value={form.cropHealthScore}
                    onChange={(e) => setForm({ ...form, cropHealthScore: e.target.value })}
                    required
                  />
                  <span style={{ fontSize: '0.78rem', color: Number(form.cropHealthScore) < 6 ? '#dc2626' : '#16a34a', fontWeight: 600 }}>
                    {Number(form.cropHealthScore) < 6 ? '⚠️ Score < 6 flags contract AT_RISK' : '✓ Healthy vegetative index'}
                  </span>
                </div>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label" htmlFor="fv-soil-moisture">Soil Moisture Reading</label>
                <select 
                  id="fv-soil-moisture"
                  className="form-control"
                  value={form.soilMoisture}
                  onChange={(e) => setForm({ ...form, soilMoisture: e.target.value })}
                >
                  <option value="Optimal (24%)">Optimal (24%)</option>
                  <option value="Optimal (22%)">Optimal (22%)</option>
                  <option value="Saturated (32%)">Saturated (32%) - Over-irrigated</option>
                  <option value="Deficient (14%)">Deficient (14%) - Irrigation Needed</option>
                  <option value="Deficient (12%)">Deficient (12%) - Drought Stress</option>
                  <option value="Dry (11%)">Dry (11%) - Harvest Ready</option>
                </select>
              </div>

              <div className="form-group" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="form-label">Pest & Disease Status</label>
                <label 
                  htmlFor="fv-pest-alert"
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '10px', 
                    padding: '9px 14px', 
                    borderRadius: '8px',
                    border: form.pestAlert ? '1px solid #f87171' : '1px solid #e2e8f0',
                    background: form.pestAlert ? '#fee2e2' : '#f8faf8',
                    cursor: 'pointer' 
                  }}
                >
                  <input 
                    id="fv-pest-alert"
                    type="checkbox"
                    checked={form.pestAlert}
                    onChange={(e) => setForm({ ...form, pestAlert: e.target.checked })}
                    style={{ width: 18, height: 18, cursor: 'pointer' }}
                  />
                  <span style={{ fontSize: '0.86rem', fontWeight: 700, color: form.pestAlert ? '#b91c1c' : '#334155' }}>
                    {form.pestAlert ? '🚨 Pest/Blight Outbreak Detected (AI Auto-Escalation)' : '🛡️ No active pest infestation'}
                  </span>
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="fv-remarks">Agronomist Observations & Advisory Instructions</label>
              <textarea 
                id="fv-remarks"
                className="form-control"
                rows="2"
                value={form.remarks}
                onChange={(e) => setForm({ ...form, remarks: e.target.value })}
                placeholder="Enter field officer observations, weed status, fertilizer suggestions..."
                required
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '12px' }}>
              <button 
                type="button" 
                className="btn btn-outline"
                onClick={() => setIsFormOpen(false)}
              >
                Collapse Form
              </button>
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={submitting}
              >
                {submitting ? <div className="spinner"></div> : <CheckCircle2 size={16} />}
                <span>Submit Field Visit & Trigger AI Evaluation</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Field Visits History Table */}
      <div className="table-card">
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#1b4332' }}>
            Historical Field Officer Inspections ({visits.length})
          </h3>
          <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
            Live Synchronized with Sowing & Compliance AI Auditor
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="custom-table">
            <thead>
              <tr>
                <th>Visit Date</th>
                <th>Contract Code</th>
                <th>Farmer & Location</th>
                <th>Crop Type</th>
                <th>Field Officer</th>
                <th>Health Score</th>
                <th>Pest Alert</th>
                <th>Soil Moisture</th>
                <th>Agronomist Observations</th>
              </tr>
            </thead>
            <tbody>
              {visits.length === 0 ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '36px', color: '#94a3b8' }}>
                    No field visits recorded yet. Use the form above to log an inspection.
                  </td>
                </tr>
              ) : (
                visits.map((v) => (
                  <tr key={v.id}>
                    <td style={{ fontWeight: 600, fontSize: '0.82rem' }}>{v.visitDate}</td>
                    <td>
                      <span className="contract-code-cell">
                        <Sprout size={13} color="#2d6a4f" />
                        {v.contract?.contractCode}
                      </span>
                    </td>
                    <td>
                      <div className="farmer-cell">
                        <span className="farmer-name">{v.contract?.farmer?.name}</span>
                        <span className="farmer-location">{v.contract?.farmer?.village}, {v.contract?.farmer?.district}</span>
                      </div>
                    </td>
                    <td>
                      <span className="crop-tag">{v.contract?.cropType}</span>
                    </td>
                    <td style={{ fontWeight: 600, color: '#334155' }}>{v.officerName}</td>
                    <td>
                      <span className={`score-badge ${v.cropHealthScore >= 7 ? 'score-high' : v.cropHealthScore >= 5 ? 'score-mid' : 'score-low'}`}>
                        {v.cropHealthScore}
                      </span>
                    </td>
                    <td>
                      {v.pestAlert ? (
                        <span className="badge badge-at_risk">
                          <AlertTriangle size={12} /> Pest Alert
                        </span>
                      ) : (
                        <span className="badge badge-active">
                          <CheckCircle2 size={12} /> Clear
                        </span>
                      )}
                    </td>
                    <td style={{ fontSize: '0.82rem', color: '#475569' }}>{v.soilMoisture}</td>
                    <td style={{ fontSize: '0.82rem', color: '#1e293b', maxWidth: '320px' }}>
                      {v.remarks}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
