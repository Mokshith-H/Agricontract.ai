import React from 'react';
import { 
  FileCheck2, 
  AlertTriangle, 
  Percent, 
  Scale, 
  DollarSign, 
  CheckCircle2, 
  Clock 
} from 'lucide-react';

export default function KPICards({ summary }) {
  if (!summary) return null;

  const {
    totalContracts = 0,
    activeContracts = 0,
    atRiskContracts = 0,
    sowingComplianceRate = 0,
    totalExpectedYieldTons = 0,
    totalDeliveredTons = 0,
    yieldFulfillmentRate = 0,
    eligiblePaymentsAmount = 0,
    disbursedPaymentsAmount = 0,
    pendingApprovalMilestonesCount = 0
  } = summary;

  return (
    <div className="kpi-grid">
      {/* 1. Active & Monitored Contracts */}
      <div className="kpi-card">
        <div className="kpi-header">
          <span className="kpi-title">Active Contracts</span>
          <div className="kpi-icon-wrapper icon-green">
            <FileCheck2 size={20} />
          </div>
        </div>
        <div className="kpi-value">{activeContracts} <span style={{ fontSize: '1rem', color: '#64748b' }}>/ {totalContracts}</span></div>
        <div className="kpi-footer">
          {atRiskContracts > 0 ? (
            <span style={{ color: '#d90429', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <AlertTriangle size={14} /> {atRiskContracts} Contract(s) Flagged At-Risk
            </span>
          ) : (
            <span style={{ color: '#16a34a', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <CheckCircle2 size={14} /> All Contracts On Schedule
            </span>
          )}
        </div>
        <div className="kpi-progress">
          <div 
            className="kpi-progress-bar" 
            style={{ 
              width: `${totalContracts > 0 ? (activeContracts / totalContracts) * 100 : 0}%`, 
              backgroundColor: '#10b981' 
            }}
          />
        </div>
      </div>

      {/* 2. Sowing Advisory Compliance */}
      <div className="kpi-card">
        <div className="kpi-header">
          <span className="kpi-title">Sowing Compliance</span>
          <div className="kpi-icon-wrapper icon-amber">
            <Percent size={20} />
          </div>
        </div>
        <div className="kpi-value">{sowingComplianceRate}%</div>
        <div className="kpi-footer">
          <span>Advisory adherence across land prep & sowing stages</span>
        </div>
        <div className="kpi-progress">
          <div 
            className="kpi-progress-bar" 
            style={{ 
              width: `${Math.min(100, sowingComplianceRate)}%`, 
              backgroundColor: sowingComplianceRate >= 80 ? '#10b981' : '#f59e0b' 
            }}
          />
        </div>
      </div>

      {/* 3. Expected vs Delivered Volume */}
      <div className="kpi-card">
        <div className="kpi-header">
          <span className="kpi-title">Procured Volume</span>
          <div className="kpi-icon-wrapper icon-blue">
            <Scale size={20} />
          </div>
        </div>
        <div className="kpi-value">
          {Number(totalDeliveredTons).toLocaleString()} <span style={{ fontSize: '0.95rem', color: '#64748b' }}>/ {Number(totalExpectedYieldTons).toLocaleString()} T</span>
        </div>
        <div className="kpi-footer">
          <span>Fulfillment Target: <strong>{yieldFulfillmentRate}%</strong></span>
        </div>
        <div className="kpi-progress">
          <div 
            className="kpi-progress-bar" 
            style={{ 
              width: `${Math.min(100, yieldFulfillmentRate)}%`, 
              backgroundColor: '#0284c7' 
            }}
          />
        </div>
      </div>

      {/* 4. Automated Milestone Payments */}
      <div className="kpi-card">
        <div className="kpi-header">
          <span className="kpi-title">Eligible Payouts</span>
          <div className="kpi-icon-wrapper icon-purple">
            <DollarSign size={20} />
          </div>
        </div>
        <div className="kpi-value">${Number(eligiblePaymentsAmount).toLocaleString()}</div>
        <div className="kpi-footer">
          <span>{pendingApprovalMilestonesCount} Milestone(s) unlocked & pending approval</span>
        </div>
        <div className="kpi-progress">
          <div 
            className="kpi-progress-bar" 
            style={{ 
              width: '100%', 
              backgroundColor: '#8b5cf6' 
            }}
          />
        </div>
      </div>
    </div>
  );
}
