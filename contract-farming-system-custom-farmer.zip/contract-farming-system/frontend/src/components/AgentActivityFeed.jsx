import React from 'react';
import { 
  Bot, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  DollarSign, 
  Truck, 
  ShieldAlert 
} from 'lucide-react';

export default function AgentActivityFeed({ logs, onRunAudit, isAuditing }) {
  const getIcon = (type, severity) => {
    if (severity === 'CRITICAL' || type.includes('RISK')) {
      return <AlertTriangle size={15} color="#dc2626" />;
    }
    if (type.includes('MILESTONE') || type.includes('PAYMENT')) {
      return <DollarSign size={15} color="#7c3aed" />;
    }
    if (type.includes('DELIVERY') || type.includes('PROCUREMENT')) {
      return <Truck size={15} color="#0284c7" />;
    }
    return <CheckCircle2 size={15} color="#16a34a" />;
  };

  const formatTime = (ts) => {
    if (!ts) return 'Just now';
    try {
      const date = new Date(ts);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ', ' + date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } catch (e) {
      return ts;
    }
  };

  return (
    <div className="agent-feed-card">
      <div className="card-header-flex">
        <div className="card-title">
          <Bot size={20} color="#2d6a4f" />
          <span>Autonomous AI Agent Activity Feed</span>
        </div>
        <button 
          className="btn btn-outline btn-sm"
          onClick={onRunAudit}
          disabled={isAuditing}
        >
          {isAuditing ? <div className="spinner"></div> : <Sparkles size={14} color="#059669" />}
          <span>Run Audit</span>
        </button>
      </div>

      <p style={{ fontSize: '0.82rem', color: '#64748b' }}>
        Live timeline of autonomous compliance checks, field visit health audits, and milestone payment unlocks.
      </p>

      <div className="timeline">
        {(!logs || logs.length === 0) ? (
          <div style={{ textAlign: 'center', padding: '30px', color: '#94a3b8', fontSize: '0.9rem' }}>
            No agent action logs recorded yet. Click "Run Autonomous AI Audit" above to scan.
          </div>
        ) : (
          logs.slice(0, 7).map((log) => (
            <div key={log.id} className={`timeline-item severity-${log.severity?.toLowerCase() || 'info'}`}>
              <div className="timeline-icon-box">
                {getIcon(log.actionType, log.severity)}
              </div>
              <div className="timeline-content">
                <div className="timeline-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="timeline-agent">{log.agentName}</span>
                    {log.contractCode && (
                      <span className="timeline-code-pill">{log.contractCode}</span>
                    )}
                  </div>
                  <span className="timeline-time">{formatTime(log.timestamp)}</span>
                </div>
                <div className="timeline-reasoning">
                  {log.reasoning}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
