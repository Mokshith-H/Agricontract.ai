import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, User, RefreshCw } from 'lucide-react';
import { sendCopilotChat } from '../api';

export default function AICopilotDrawer() {
  const [messages, setMessages] = useState([
    {
      sender: 'bot',
      text: "👋 Hello! I am your **Contract-Farming Agentic Copilot**.\n\nI continuously synthesize sowing compliance, field inspection health scores, pest outbreaks, and harvest deliveries into actionable farmer relations insights. How can I help you?",
      suggestedActions: [
        "Which contracts are at risk?",
        "Show pending payment milestones",
        "What is overall sowing compliance?",
        "Audit contract sowing windows"
      ]
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSend = async (textToSend) => {
    const query = textToSend || input;
    if (!query || !query.trim() || loading) return;

    const userMessage = { sender: 'user', text: query };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await sendCopilotChat(query);
      const botMessage = {
        sender: 'bot',
        text: response.data?.reply || 'Received analysis.',
        suggestedActions: response.data?.suggestedActions || [],
        reasoningContext: response.data?.reasoningContext
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      setMessages(prev => [
        ...prev, 
        { 
          sender: 'bot', 
          text: "I encountered an error querying the contract database. Please verify the backend connection.",
          suggestedActions: ["Which contracts are at risk?", "Show pending payment milestones"]
        }
      ]);
    }
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  return (
    <div className="copilot-panel">
      <div className="copilot-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: 34, height: 34, borderRadius: '8px', background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Bot size={20} color="#fff" />
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: '1rem' }}>Agentic Copilot Chat</div>
            <div style={{ fontSize: '0.72rem', opacity: 0.9 }}>Live Agricultural Multi-Agent Reasoning</div>
          </div>
        </div>
        <span style={{ fontSize: '0.75rem', background: 'rgba(255,255,255,0.2)', padding: '2px 8px', borderRadius: '12px' }}>
          Online
        </span>
      </div>

      <div className="copilot-chat-body">
        {messages.map((m, idx) => (
          <div key={idx} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className={`chat-bubble ${m.sender}`}>
              <div style={{ whiteSpace: 'pre-line' }}>{m.text}</div>
              {m.reasoningContext && (
                <div style={{ marginTop: '8px', fontSize: '0.72rem', color: '#64748b', fontStyle: 'italic', borderTop: '1px dashed #cbd5e1', paddingTop: '4px' }}>
                  🧠 Context: {m.reasoningContext}
                </div>
              )}
            </div>

            {m.suggestedActions && m.suggestedActions.length > 0 && (
              <div className="prompt-suggestions">
                {m.suggestedActions.map((action, sIdx) => (
                  <button
                    key={sIdx}
                    type="button"
                    className="suggestion-pill"
                    onClick={() => handleSend(action)}
                  >
                    <Sparkles size={11} style={{ marginRight: 4 }} />
                    {action}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="chat-bubble bot" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#64748b' }}>
            <div className="spinner" style={{ borderTopColor: '#2d6a4f' }}></div>
            <span>Evaluating contract-farming database & running agronomic reasoning...</span>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <form 
        className="copilot-input-area"
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
      >
        <input 
          ref={inputRef}
          type="text"
          className="form-control"
          placeholder="Ask e.g. 'Which contracts are at risk?' or 'Show pending payment milestones'..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          aria-label="Ask Agentic Copilot question"
          autoFocus
        />
        <button 
          type="submit"
          className="btn btn-primary"
          disabled={loading || !input.trim()}
          aria-label="Send query"
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
}
