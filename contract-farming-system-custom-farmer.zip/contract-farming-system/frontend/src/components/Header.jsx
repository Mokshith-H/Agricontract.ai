import React from 'react';
import { Sparkles, RefreshCw, PlusCircle, CheckCircle2 } from 'lucide-react';

export default function Header({ onRunAudit, isAuditing, onOpenNewContract, onRefresh, lastUpdated }) {
  return (
    <header className="header">
      <div className="header-left">
        <h1>
          Contract-Farming Agentic AI Platform
        </h1>
        <p>
          Autonomously monitoring sowing compliance, field agronomics, harvest delivery reconciliations, and payout milestones.
        </p>
      </div>

      <div className="header-actions">
        <button 
          className="btn btn-outline btn-sm"
          onClick={onRefresh}
          title="Refresh database records"
        >
          <RefreshCw size={15} />
          <span>Refresh</span>
        </button>

        <button 
          className="btn btn-ai-audit"
          onClick={onRunAudit}
          disabled={isAuditing}
          title="Trigger full autonomous compliance and milestone trigger scan"
        >
          {isAuditing ? (
            <>
              <div className="spinner"></div>
              <span>Auditing Contracts...</span>
            </>
          ) : (
            <>
              <Sparkles size={16} />
              <span>Run Autonomous AI Audit</span>
            </>
          )}
        </button>

        <button 
          className="btn btn-primary"
          onClick={onOpenNewContract}
        >
          <PlusCircle size={16} />
          <span>New Contract</span>
        </button>
      </div>
    </header>
  );
}
