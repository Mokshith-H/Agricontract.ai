import React, { useState, useEffect, useRef } from 'react';
import { 
  Truck, 
  DollarSign, 
  PlusCircle, 
  CheckCircle2, 
  Sparkles, 
  Sprout, 
  Clock, 
  Unlock, 
  ShieldCheck, 
  ArrowRight,
  ChevronUp,
  ChevronDown,
  Calculator
} from 'lucide-react';
import { 
  fetchProcurements, 
  recordProcurement, 
  fetchPayments, 
  approvePayment, 
  unlockPayment, 
  fetchContracts 
} from '../api';

export default function ProcurementPaymentsView({ onActionComplete }) {
  const [procurements, setProcurements] = useState([]);
  const [payments, setPayments] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [submittingDelivery, setSubmittingDelivery] = useState(false);
  const [actionInProgressId, setActionInProgressId] = useState(null);
  const [notification, setNotification] = useState('');
  const [milestoneFilter, setMilestoneFilter] = useState('ALL');
  const [isDeliveryFormOpen, setIsDeliveryFormOpen] = useState(true);
  const deliveryInputRef = useRef(null);

  const [deliveryForm, setDeliveryForm] = useState({
    contractId: '',
    deliveryDate: new Date().toISOString().split('T')[0],
    deliveredTons: 10,
    qualityGrade: 'GRADE_A',
    receiptNumber: '',
    payoutAmount: ''
  });

  const loadData = async () => {
    try {
      const [prRes, payRes, cRes] = await Promise.all([
        fetchProcurements(),
        fetchPayments(),
        fetchContracts()
      ]);
      setProcurements(prRes.data || []);
      setPayments(payRes.data || []);
      setContracts(cRes.data || []);
      if (cRes.data?.length > 0 && !deliveryForm.contractId) {
        const first = cRes.data[0];
        const defaultTons = 10;
        const initialPayout = (first.pricePerTon ? defaultTons * Number(first.pricePerTon) : 0).toFixed(2);
        setDeliveryForm(prev => ({ 
          ...prev, 
          contractId: first.id,
          payoutAmount: initialPayout
        }));
      }
    } catch (e) {
      console.error('Error loading procurement data:', e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // When selected contract or delivered tons change, auto-calculate payout amount
  const handleContractChange = (newContractId) => {
    const selected = contracts.find(c => String(c.id) === String(newContractId));
    const price = selected?.pricePerTon ? Number(selected.pricePerTon) : 0;
    const tons = Number(deliveryForm.deliveredTons) || 0;
    const calc = (price * tons).toFixed(2);
    setDeliveryForm(prev => ({
      ...prev,
      contractId: newContractId,
      payoutAmount: calc
    }));
  };

  const handleTonsChange = (newTons) => {
    const selected = contracts.find(c => String(c.id) === String(deliveryForm.contractId));
    const price = selected?.pricePerTon ? Number(selected.pricePerTon) : 0;
    const tons = Number(newTons) || 0;
    const calc = (price * tons).toFixed(2);
    setDeliveryForm(prev => ({
      ...prev,
      deliveredTons: newTons,
      payoutAmount: calc
    }));
  };

  const handleRecordDelivery = async (e) => {
    e.preventDefault();
    if (!deliveryForm.contractId) {
      alert('Please select a contract.');
      return;
    }
    setSubmittingDelivery(true);
    try {
      await recordProcurement({
        ...deliveryForm,
        contractId: Number(deliveryForm.contractId),
        deliveredTons: Number(deliveryForm.deliveredTons),
        payoutAmount: Number(deliveryForm.payoutAmount)
      });
      setSubmittingDelivery(false);
      setNotification(`Delivery of ${deliveryForm.deliveredTons} Tons recorded ($${Number(deliveryForm.payoutAmount).toLocaleString()})! Procurement AI checked yield milestones.`);
      setTimeout(() => setNotification(''), 5500);
      // Reset receipt number for next entry
      setDeliveryForm(prev => ({
        ...prev,
        receiptNumber: ''
      }));
      await loadData();
      if (onActionComplete) onActionComplete();
    } catch (err) {
      setSubmittingDelivery(false);
      alert('Failed to record delivery. Please verify inputs.');
    }
  };

  const handleApprovePayout = async (milestoneId) => {
    setActionInProgressId(milestoneId);
    try {
      await approvePayment(milestoneId);
      setNotification('Milestone payout approved! Disbursal instructions dispatched to Agri-Banking Gateway.');
      setTimeout(() => setNotification(''), 5500);
      await loadData();
      if (onActionComplete) onActionComplete();
    } catch (err) {
      alert('Failed to approve payment.');
    }
    setActionInProgressId(null);
  };

  const handleUnlockMilestone = async (milestoneId) => {
    setActionInProgressId(milestoneId);
    try {
      await unlockPayment(milestoneId);
      setNotification('Milestone manually unlocked to ELIGIBLE status!');
      setTimeout(() => setNotification(''), 5500);
      await loadData();
      if (onActionComplete) onActionComplete();
    } catch (err) {
      alert('Failed to unlock milestone.');
    }
    setActionInProgressId(null);
  };

  const filteredMilestones = payments.filter(p => {
    if (milestoneFilter === 'ALL') return true;
    return p.status === milestoneFilter;
  });

  const eligibleCount = payments.filter(p => p.status === 'ELIGIBLE').length;
  const eligibleSum = payments
    .filter(p => p.status === 'ELIGIBLE')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const selectedContract = contracts.find(c => String(c.id) === String(deliveryForm.contractId));

  return (
    <div>
      {notification && (
        <div className="toast-bar" style={{ position: 'relative', bottom: 'auto', right: 'auto', marginBottom: '20px', background: '#064e3b', border: '1px solid #059669' }}>
          <Sparkles size={18} color="#34d399" />
          <span>{notification}</span>
        </div>
      )}

      {/* SECTION 1: Record Procurement & Amount Form */}
      <div style={{ marginBottom: '28px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#1b4332', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Truck size={22} color="#2d6a4f" />
              <span>Record Harvest Procurement & Weighbridge Delivery</span>
            </h2>
            <p style={{ fontSize: '0.83rem', color: '#64748b' }}>
              Log incoming farmer truckloads, verify quality grade, and auto-calculate harvest procurement settlement amounts.
            </p>
          </div>
          <button 
            type="button"
            className="btn btn-primary"
            onClick={() => {
              setIsDeliveryFormOpen(!isDeliveryFormOpen);
              setTimeout(() => deliveryInputRef.current?.focus(), 100);
            }}
            aria-expanded={isDeliveryFormOpen}
          >
            {isDeliveryFormOpen ? <ChevronUp size={16} /> : <PlusCircle size={16} />}
            <span>{isDeliveryFormOpen ? 'Hide Delivery Form' : '+ New Delivery Entry'}</span>
          </button>
        </div>

        {isDeliveryFormOpen && (
          <div className="table-card" style={{ padding: '24px', border: '2px solid #52b788', background: '#ffffff' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '18px' }}>
              <Calculator size={18} color="#2d6a4f" />
              <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: '#1b4332' }}>
                Weighbridge Receipt & Payout Calculator
              </h3>
            </div>

            <form onSubmit={handleRecordDelivery}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label" htmlFor="proc-contract-select">Target Farmer Contract</label>
                  <select 
                    id="proc-contract-select"
                    ref={deliveryInputRef}
                    className="form-control"
                    value={deliveryForm.contractId}
                    onChange={(e) => handleContractChange(e.target.value)}
                    required
                  >
                    {contracts.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.contractCode} — {c.farmer?.name} ({c.cropType}, Rate: ${c.pricePerTon}/Ton, Target: {c.expectedYieldTons} T)
                      </option>
                    ))}
                  </select>
                  {selectedContract && (
                    <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '4px' }}>
                      Agreed MSP: <strong>${selectedContract.pricePerTon}/Ton</strong> | Variety: {selectedContract.variety} | Farmer: {selectedContract.farmer?.name}
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="proc-date">Weighbridge Delivery Date</label>
                  <input 
                    id="proc-date"
                    type="date"
                    className="form-control"
                    value={deliveryForm.deliveryDate}
                    onChange={(e) => setDeliveryForm({ ...deliveryForm, deliveryDate: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label" htmlFor="proc-tons">Delivered Net Weight (Tons)</label>
                  <input 
                    id="proc-tons"
                    type="number"
                    step="0.1"
                    min="0.1"
                    className="form-control"
                    value={deliveryForm.deliveredTons}
                    onChange={(e) => handleTonsChange(e.target.value)}
                    placeholder="e.g. 15.5"
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="proc-quality">Quality Inspection Grade</label>
                  <select 
                    id="proc-quality"
                    className="form-control"
                    value={deliveryForm.qualityGrade}
                    onChange={(e) => setDeliveryForm({ ...deliveryForm, qualityGrade: e.target.value })}
                  >
                    <option value="GRADE_A">Grade A (Premium Export Quality — 100% MSP)</option>
                    <option value="GRADE_B">Grade B (Standard Commercial — 95% MSP)</option>
                    <option value="REJECTED">Rejected (Excessive moisture or damage)</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label" htmlFor="proc-receipt">Weighbridge Receipt / Slip Number</label>
                  <input 
                    id="proc-receipt"
                    type="text"
                    className="form-control"
                    placeholder="Leave blank to auto-generate (e.g. RCPT-WHT-XXXX)"
                    value={deliveryForm.receiptNumber}
                    onChange={(e) => setDeliveryForm({ ...deliveryForm, receiptNumber: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="proc-payout">Calculated Harvest Payout Amount ($)</label>
                  <div style={{ position: 'relative' }}>
                    <input 
                      id="proc-payout"
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={deliveryForm.payoutAmount}
                      onChange={(e) => setDeliveryForm({ ...deliveryForm, payoutAmount: e.target.value })}
                      required
                    />
                    <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.78rem', color: '#16a34a', fontWeight: 700 }}>
                      Auto-Calculated
                    </span>
                  </div>
                  <small style={{ color: '#64748b', fontSize: '0.72rem' }}>
                    {deliveryForm.deliveredTons} Tons × ${selectedContract?.pricePerTon || 0}/Ton = ${deliveryForm.payoutAmount}
                  </small>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '8px' }}>
                <button 
                  type="button" 
                  className="btn btn-outline"
                  onClick={() => setIsDeliveryFormOpen(false)}
                >
                  Collapse Form
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={submittingDelivery}
                >
                  {submittingDelivery ? <div className="spinner"></div> : <CheckCircle2 size={16} />}
                  <span>Confirm Receipt & Trigger AI Milestones</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* SECTION 2: Payment Milestones & Payout Queue */}
      <div style={{ marginBottom: '32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
          <div>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#1b4332', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <DollarSign size={20} color="#10b981" />
              <span>Automated Milestone Payout Queue</span>
            </h3>
            <p style={{ fontSize: '0.82rem', color: '#64748b' }}>
              Milestones autonomously unlocked when agronomic advisory compliance or harvest delivery thresholds are met.
            </p>
          </div>

          <div className="filter-pills">
            {['ALL', 'ELIGIBLE', 'LOCKED', 'APPROVED', 'PAID'].map(f => (
              <button
                key={f}
                type="button"
                className={`filter-btn ${milestoneFilter === f ? 'active' : ''}`}
                onClick={() => setMilestoneFilter(f)}
              >
                {f} {f === 'ELIGIBLE' && eligibleCount > 0 ? `(${eligibleCount})` : ''}
              </button>
            ))}
          </div>
        </div>

        <div className="table-card">
          <div style={{ padding: '12px 20px', backgroundColor: '#fefce8', borderBottom: '1px solid #fef08a', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
            <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#854d0e' }}>
              Pending Disbursal Approvals: <strong>{eligibleCount} Milestones</strong>
            </span>
            <span style={{ fontSize: '0.82rem', color: '#713f12' }}>
              Total Ready for Disbursal: <strong>${eligibleSum.toLocaleString()}</strong>
            </span>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Milestone Title</th>
                  <th>Contract Code</th>
                  <th>Farmer Name</th>
                  <th>Trigger Condition</th>
                  <th>Payout Amount</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredMilestones.length === 0 ? (
                  <tr>
                    <td colSpan="7" style={{ textAlign: 'center', padding: '28px', color: '#94a3b8' }}>
                      No milestones matching filter "{milestoneFilter}".
                    </td>
                  </tr>
                ) : (
                  filteredMilestones.map((m) => (
                    <tr key={m.id} style={{ backgroundColor: m.status === 'ELIGIBLE' ? '#fffbeb' : 'inherit' }}>
                      <td style={{ fontWeight: 700, color: '#1e293b' }}>{m.milestoneTitle}</td>
                      <td>
                        <span className="contract-code-cell">
                          <Sprout size={13} color="#2d6a4f" />
                          {m.contract?.contractCode}
                        </span>
                      </td>
                      <td>
                        <span style={{ fontWeight: 600 }}>{m.contract?.farmer?.name}</span>
                      </td>
                      <td style={{ fontSize: '0.8rem', color: '#64748b', maxWidth: 240 }}>
                        {m.triggerCondition}
                      </td>
                      <td>
                        <span style={{ fontSize: '0.98rem', fontWeight: 800, color: '#047857' }}>
                          ${Number(m.amount).toLocaleString()}
                        </span>
                      </td>
                      <td>
                        <span className={`badge badge-${m.status?.toLowerCase()}`}>
                          {m.status}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '6px' }}>
                          {m.status === 'ELIGIBLE' && (
                            <button
                              type="button"
                              className="btn btn-success btn-sm"
                              onClick={() => handleApprovePayout(m.id)}
                              disabled={actionInProgressId === m.id}
                              aria-label={`Approve payout for ${m.milestoneTitle}`}
                            >
                              {actionInProgressId === m.id ? (
                                <div className="spinner"></div>
                              ) : (
                                <CheckCircle2 size={14} />
                              )}
                              <span>Approve Payout</span>
                            </button>
                          )}

                          {m.status === 'LOCKED' && (
                            <button
                              type="button"
                              className="btn btn-outline btn-sm"
                              onClick={() => handleUnlockMilestone(m.id)}
                              disabled={actionInProgressId === m.id}
                              title="Manually unlock milestone to ELIGIBLE"
                              aria-label={`Unlock milestone ${m.milestoneTitle}`}
                            >
                              {actionInProgressId === m.id ? (
                                <div className="spinner"></div>
                              ) : (
                                <Unlock size={14} />
                              )}
                              <span>Unlock</span>
                            </button>
                          )}

                          {m.status === 'APPROVED' && (
                            <span style={{ fontSize: '0.78rem', color: '#059669', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                              <CheckCircle2 size={13} /> Queued for Bank
                            </span>
                          )}

                          {m.status === 'PAID' && (
                            <span style={{ fontSize: '0.78rem', color: '#4338ca', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                              ✓ Disbursed
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* SECTION 3: Recent Procurement Deliveries Table */}
      <div style={{ marginBottom: '24px' }}>
        <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1b4332', marginBottom: '12px' }}>
          Recent Harvest Procurement Deliveries ({procurements.length})
        </h3>
        <div className="table-card">
          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Weighbridge Receipt</th>
                  <th>Delivery Date</th>
                  <th>Contract Code</th>
                  <th>Farmer & Location</th>
                  <th>Crop</th>
                  <th>Delivered Net Weight</th>
                  <th>Quality Grade</th>
                  <th>Settlement Amount</th>
                </tr>
              </thead>
              <tbody>
                {procurements.length === 0 ? (
                  <tr>
                    <td colSpan="8" style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>
                      No procurement receipts logged yet.
                    </td>
                  </tr>
                ) : (
                  procurements.map((p) => (
                    <tr key={p.id}>
                      <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: '#2d6a4f' }}>
                        {p.receiptNumber}
                      </td>
                      <td style={{ fontSize: '0.84rem' }}>{p.deliveryDate}</td>
                      <td>
                        <span className="contract-code-cell">
                          <Sprout size={13} color="#2d6a4f" />
                          {p.contract?.contractCode}
                        </span>
                      </td>
                      <td>
                        {p.contract?.farmer?.name} ({p.contract?.farmer?.village})
                      </td>
                      <td>
                        <span className="crop-tag">{p.contract?.cropType}</span>
                      </td>
                      <td>
                        <strong style={{ fontSize: '0.95rem', color: '#0f172a' }}>{p.deliveredTons}</strong> Tons
                      </td>
                      <td>
                        <span className="badge badge-completed">{p.qualityGrade}</span>
                      </td>
                      <td>
                        <strong style={{ color: '#047857', fontSize: '0.95rem' }}>
                          ${p.payoutAmount ? Number(p.payoutAmount).toLocaleString() : '—'}
                        </strong>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
