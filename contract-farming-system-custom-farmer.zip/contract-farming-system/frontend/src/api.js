import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Dashboard & Stats
export const fetchDashboardSummary = () => api.get('/dashboard/summary');

// Contracts
export const fetchContracts = () => api.get('/contracts');
export const fetchContractById = (id) => api.get(`/contracts/${id}`);
export const fetchContractDetails = (id) => api.get(`/contracts/${id}/details`);
export const createContract = (data) => api.post('/contracts', data);

// Farmers
export const fetchFarmers = () => api.get('/farmers');
export const createFarmer = (data) => api.post('/farmers', data);

// Field Visits
export const fetchFieldVisits = () => api.get('/field-visits');
export const recordFieldVisit = (data) => api.post('/field-visits', data);

// Procurement & Deliveries
export const fetchProcurements = () => api.get('/procurement');
export const recordProcurement = (data) => api.post('/procurement', data);

// Payments
export const fetchPayments = () => api.get('/payments');
export const unlockPayment = (id) => api.patch(`/payments/${id}/unlock`);
export const approvePayment = (id) => api.patch(`/payments/${id}/approve`);
export const markPaymentPaid = (id) => api.patch(`/payments/${id}/pay`);

// Agentic AI
export const runAgentAudit = () => api.post('/agent/run-audit');
export const sendCopilotChat = (message) => api.post('/agent/chat', { message });
export const fetchAgentLogs = () => api.get('/agent/logs');
