import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import KPICards from './components/KPICards';
import ChartsSection from './components/ChartsSection';
import AgentActivityFeed from './components/AgentActivityFeed';
import ContractsTable from './components/ContractsTable';
import ContractDetailModal from './components/ContractDetailModal';
import NewContractModal from './components/NewContractModal';
import FieldVisitsView from './components/FieldVisitsView';
import ProcurementPaymentsView from './components/ProcurementPaymentsView';
import AICopilotDrawer from './components/AICopilotDrawer';

import { 
  fetchDashboardSummary, 
  fetchContracts, 
  fetchContractDetails, 
  fetchContractById,
  runAgentAudit, 
  fetchAgentLogs 
} from './api';

export default function App() {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [summary, setSummary] = useState(null);
  const [contracts, setContracts] = useState([]);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAuditing, setIsAuditing] = useState(false);
  
  // Details Modal States
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isDetailsLoading, setIsDetailsLoading] = useState(false);
  const [detailsError, setDetailsError] = useState(null);
  const [selectedContractDetails, setSelectedContractDetails] = useState(null);
  const [activeContractId, setActiveContractId] = useState(null);

  // New Contract Modal State
  const [isNewContractOpen, setIsNewContractOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 5500);
  };

  const loadAllData = async () => {
    try {
      const [sumRes, conRes, logRes] = await Promise.all([
        fetchDashboardSummary(),
        fetchContracts(),
        fetchAgentLogs()
      ]);
      setSummary(sumRes.data);
      setContracts(conRes.data);
      setLogs(logRes.data);
    } catch (err) {
      console.error('Failed to load application data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const handleRunAudit = async () => {
    setIsAuditing(true);
    try {
      const res = await runAgentAudit();
      const { auditedContractsCount, flaggedRiskCount, unlockedMilestonesCount } = res.data;
      showToast(`AI Audit Complete: ${auditedContractsCount} Contracts Scanned, ${flaggedRiskCount} At-Risk, ${unlockedMilestonesCount} Milestones Unlocked.`);
      await loadAllData();
    } catch (err) {
      alert('Error executing autonomous audit.');
    } finally {
      setIsAuditing(false);
    }
  };

  const handleSelectContract = async (contractId) => {
    setActiveContractId(contractId);
    setIsDetailsOpen(true);
    setIsDetailsLoading(true);
    setDetailsError(null);
    setSelectedContractDetails(null);

    try {
      // Primary: fetchContractDetails
      const res = await fetchContractDetails(contractId);
      setSelectedContractDetails(res.data);
    } catch (err) {
      console.warn('fetchContractDetails failed, attempting fetchContractById fallback:', err);
      try {
        const fallbackRes = await fetchContractById(contractId);
        setSelectedContractDetails(fallbackRes.data);
      } catch (fbErr) {
        console.error('Failed both details endpoints:', fbErr);
        setDetailsError('Unable to extract contract details. Please verify backend connection.');
      }
    } finally {
      setIsDetailsLoading(false);
    }
  };

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <Sidebar 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        atRiskCount={summary?.atRiskContracts || 0}
        pendingPaymentsCount={summary?.pendingApprovalMilestonesCount || 0}
      />

      <div className="main-wrapper">
        {/* Header Bar */}
        <Header 
          onRunAudit={handleRunAudit}
          isAuditing={isAuditing}
          onOpenNewContract={() => setIsNewContractOpen(true)}
          onRefresh={loadAllData}
        />

        <main className="main-content" id="main-content-region">
          {/* View Tab: Dashboard */}
          {currentTab === 'dashboard' && (
            <div>
              <KPICards summary={summary} />
              
              <ChartsSection 
                cropYieldBreakdown={summary?.cropYieldBreakdown}
                statusBreakdown={summary?.statusBreakdown}
              />

              <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '24px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1b4332' }}>
                      Priority Monitored Contracts
                    </h3>
                    <button 
                      type="button"
                      className="btn btn-outline btn-sm"
                      onClick={() => setCurrentTab('contracts')}
                    >
                      View All ({contracts.length})
                    </button>
                  </div>
                  <ContractsTable 
                    contracts={contracts.slice(0, 5)} 
                    onSelectContract={handleSelectContract}
                    onNewContract={() => setIsNewContractOpen(true)}
                  />
                </div>

                <div>
                  <AgentActivityFeed 
                    logs={logs} 
                    onRunAudit={handleRunAudit}
                    isAuditing={isAuditing}
                  />
                </div>
              </div>
            </div>
          )}

          {/* View Tab: Contracts & Lifecycle Tracker */}
          {currentTab === 'contracts' && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <div>
                  <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#1b4332' }}>
                    Farmer Contracts & Autonomous Lifecycle Tracker
                  </h2>
                  <p style={{ fontSize: '0.83rem', color: '#64748b' }}>
                    Track agreements from signing and sowing verification through harvest procurement and final settlement.
                  </p>
                </div>
                <button 
                  type="button"
                  className="btn btn-primary" 
                  onClick={() => setIsNewContractOpen(true)}
                >
                  + Onboard New Contract
                </button>
              </div>

              <ContractsTable 
                contracts={contracts} 
                onSelectContract={handleSelectContract}
                onNewContract={() => setIsNewContractOpen(true)}
              />
            </div>
          )}

          {/* View Tab: Field Visits & Agronomic Compliance */}
          {currentTab === 'visits' && (
            <FieldVisitsView onActionComplete={loadAllData} />
          )}

          {/* View Tab: Procurement Deliveries & Payments */}
          {currentTab === 'procurement' && (
            <ProcurementPaymentsView onActionComplete={loadAllData} />
          )}

          {/* View Tab: AI Copilot Drawer */}
          {currentTab === 'copilot' && (
            <div style={{ maxWidth: 840, margin: '0 auto' }}>
              <div style={{ marginBottom: '20px' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#1b4332' }}>
                  Natural Language Agricultural Copilot
                </h2>
                <p style={{ fontSize: '0.83rem', color: '#64748b' }}>
                  Chat directly with the contract-farming multi-agent orchestrator. Inquires query live database tables and evaluate agronomic risk vectors in real-time.
                </p>
              </div>
              <AICopilotDrawer />
            </div>
          )}
        </main>
      </div>

      {/* Contract Detail Modal with 5-Stage Stepper */}
      {isDetailsOpen && (
        <ContractDetailModal 
          contractDetails={selectedContractDetails}
          isLoading={isDetailsLoading}
          error={detailsError}
          onClose={() => {
            setIsDetailsOpen(false);
            setSelectedContractDetails(null);
            setDetailsError(null);
          }}
          onRetry={() => activeContractId && handleSelectContract(activeContractId)}
          onRefresh={loadAllData}
        />
      )}

      {/* Onboard New Contract Modal */}
      <NewContractModal 
        isOpen={isNewContractOpen}
        onClose={() => setIsNewContractOpen(false)}
        onSuccess={() => {
          showToast('New contract successfully onboarded and advisory schedule initialized.');
          loadAllData();
        }}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="toast-bar" role="status" aria-live="polite">
          <span style={{ fontSize: '1.1rem' }}>🤖</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
