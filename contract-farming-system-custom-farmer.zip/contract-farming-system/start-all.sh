#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)

if [ -n "${JAVA_HOME:-}" ] && [ ! -x "$JAVA_HOME/bin/java" ]; then
    unset JAVA_HOME
fi
if ! command -v java >/dev/null 2>&1; then
    echo "Java 21 or newer is required. Install a JDK and add java to PATH." >&2
    exit 1
fi
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
    echo "Node.js 18 or newer (including npm) is required. Install Node.js and add it to PATH." >&2
    exit 1
fi

echo "Starting AgriContract AI..."
cd "$PROJECT_DIR/backend"
chmod +x ./mvnw
./mvnw spring-boot:run &
BACKEND_PID=$!
FRONTEND_PID=

cleanup() {
    kill "$BACKEND_PID" 2>/dev/null || true
    if [ -n "$FRONTEND_PID" ]; then
        kill "$FRONTEND_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

cd "$PROJECT_DIR/frontend"
if [ ! -d node_modules ]; then
    npm ci
fi
npm run dev &
FRONTEND_PID=$!

echo "Backend:  http://localhost:8080/api/dashboard/summary"
echo "Frontend: http://localhost:5173"
node "$PROJECT_DIR/open-app.mjs" || echo "Automatic browser launch did not complete; check the URLs above."
wait
