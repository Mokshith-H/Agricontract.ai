@echo off
title AgriContract AI - Full Stack Launcher
cd /d "%~dp0"

if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" goto java_ready
set "JAVA_HOME="
where java >nul 2>nul
if errorlevel 1 (
    echo Java 21 or newer is required. Install a JDK and add java to PATH.
    pause
    exit /b 1
)
:java_ready
where node >nul 2>nul
if errorlevel 1 (
    echo Node.js 18 or newer is required. Install Node.js and add it to PATH.
    pause
    exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
    echo npm is required. Reinstall Node.js with npm included.
    pause
    exit /b 1
)

echo ===================================================
echo   AgriContract AI (PS225) - Full Stack Launcher
echo ===================================================
echo.
echo Starting Backend (Spring Boot on port 8080)...
start "AgriContract Backend (Spring Boot)" /D "%~dp0" cmd /k "call start-backend.bat"

echo Starting Frontend (Vite on port 5173)...
start "AgriContract Frontend (Vite React)" /D "%~dp0" cmd /k "call start-frontend.bat"

echo.
echo Waiting for the backend and frontend to become ready...
node "%~dp0open-app.mjs"

echo.
echo ===================================================
echo   Both services are launching in separate windows!
echo   Frontend: http://localhost:5173
echo   Backend:  http://localhost:8080/api/dashboard/summary
echo   H2 DB:    http://localhost:8080/h2-console
echo ===================================================
pause
