package com.agri.contractfarming.dto;

import com.agri.contractfarming.model.QualityGrade;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcurementRequestDTO {
    @NotNull(message = "Contract ID is required")
    private Long contractId;

    @NotNull(message = "Delivery date is required")
    private LocalDate deliveryDate;

    @NotNull(message = "Delivered tons is required")
    @Positive(message = "Delivered tons must be positive")
    private BigDecimal deliveredTons;

    @NotNull(message = "Quality grade is required")
    private QualityGrade qualityGrade;

    private String receiptNumber;

    private BigDecimal payoutAmount;
}
