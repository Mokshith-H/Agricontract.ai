package com.agri.contractfarming.controller;

import com.agri.contractfarming.model.Farmer;
import com.agri.contractfarming.repository.FarmerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/farmers")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FarmerController {

    private final FarmerRepository farmerRepository;

    @GetMapping
    public ResponseEntity<List<Farmer>> getAllFarmers() {
        return ResponseEntity.ok(farmerRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<Farmer> createFarmer(@RequestBody Farmer farmer) {
        if (farmer.getName() == null || farmer.getName().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        if (farmer.getDistrict() == null || farmer.getDistrict().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        if (farmer.getTotalAcreage() == null || farmer.getTotalAcreage().signum() <= 0) {
            return ResponseEntity.badRequest().build();
        }

        farmer.setState(farmer.getState() == null || farmer.getState().isBlank()
                ? farmer.getDistrict() : farmer.getState());
        farmer.setVillage(farmer.getVillage() == null || farmer.getVillage().isBlank()
                ? farmer.getState() : farmer.getVillage());
        farmer.setPhone(farmer.getPhone() == null || farmer.getPhone().isBlank()
                ? "Not provided" : farmer.getPhone());
        farmer.setKycVerified(false);
        farmer.setId(null);
        return new ResponseEntity<>(farmerRepository.save(farmer), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Farmer> getFarmerById(@PathVariable Long id) {
        return farmerRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
