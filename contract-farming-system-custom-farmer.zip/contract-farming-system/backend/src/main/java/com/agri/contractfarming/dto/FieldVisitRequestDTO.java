package com.agri.contractfarming.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FieldVisitRequestDTO {
    @NotNull(message = "Contract ID is required")
    private Long contractId;

    @NotNull(message = "Officer name is required")
    private String officerName;

    @NotNull(message = "Visit date is required")
    private LocalDate visitDate;

    @NotNull(message = "Crop health score is required")
    @Min(value = 1, message = "Health score must be at least 1")
    @Max(value = 10, message = "Health score cannot exceed 10")
    private Integer cropHealthScore;

    @NotNull(message = "Pest alert status is required")
    private Boolean pestAlert;

    @NotNull(message = "Soil moisture reading is required")
    private String soilMoisture;

    private String remarks;
}
