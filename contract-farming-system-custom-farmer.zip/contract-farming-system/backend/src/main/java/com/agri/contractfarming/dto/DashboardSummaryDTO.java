package com.agri.contractfarming.dto;

import com.agri.contractfarming.model.AgentActionLog;
import lombok.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardSummaryDTO {
    private long totalContracts;
    private long activeContracts;
    private long atRiskContracts;
    private long delayedContracts;
    private long completedContracts;

    private double sowingComplianceRate; // Percentage e.g. 84.5%
    private BigDecimal totalExpectedYieldTons;
    private BigDecimal totalDeliveredTons;
    private double yieldFulfillmentRate; // Percentage

    private BigDecimal eligiblePaymentsAmount;
    private BigDecimal disbursedPaymentsAmount;
    private long pendingApprovalMilestonesCount;

    private List<CropYieldSummaryDTO> cropYieldBreakdown;
    private Map<String, Long> statusBreakdown;
    private List<AgentActionLog> recentAgentLogs;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CropYieldSummaryDTO {
        private String crop;
        private BigDecimal committedTons;
        private BigDecimal deliveredTons;
        private double fulfillmentPercent;
    }
}
