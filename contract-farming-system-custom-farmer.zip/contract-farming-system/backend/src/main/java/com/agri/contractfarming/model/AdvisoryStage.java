package com.agri.contractfarming.model;

public enum AdvisoryStage {
    LAND_PREP,
    SOWING,
    FERTILIZER,
    PEST_CONTROL,
    HARVEST
}
