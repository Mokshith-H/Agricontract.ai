package com.agri.contractfarming.repository;

import com.agri.contractfarming.model.ProcurementRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ProcurementRecordRepository extends JpaRepository<ProcurementRecord, Long> {
    List<ProcurementRecord> findByContractIdOrderByDeliveryDateDesc(Long contractId);
    List<ProcurementRecord> findAllByOrderByDeliveryDateDesc();

    @Query("SELECT COALESCE(SUM(p.deliveredTons), 0) FROM ProcurementRecord p WHERE p.contract.id = :contractId")
    BigDecimal sumDeliveredTonsByContractId(Long contractId);

    @Query("SELECT COALESCE(SUM(p.deliveredTons), 0) FROM ProcurementRecord p")
    BigDecimal sumTotalDeliveredTons();
}
