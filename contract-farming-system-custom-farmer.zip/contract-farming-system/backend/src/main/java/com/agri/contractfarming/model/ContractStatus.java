package com.agri.contractfarming.model;

public enum ContractStatus {
    ACTIVE,
    AT_RISK,
    DELAYED,
    COMPLETED
}
