package com.agri.contractfarming.dto;

import com.agri.contractfarming.model.AgentActionLog;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditResultDTO {
    private int auditedContractsCount;
    private int flaggedRiskCount;
    private int unlockedMilestonesCount;
    private int advisoriesGeneratedCount;
    private String message;
    private List<AgentActionLog> triggeredLogs;
}
