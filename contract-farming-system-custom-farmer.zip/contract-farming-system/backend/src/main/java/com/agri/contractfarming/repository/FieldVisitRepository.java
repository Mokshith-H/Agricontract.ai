package com.agri.contractfarming.repository;

import com.agri.contractfarming.model.FieldVisit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FieldVisitRepository extends JpaRepository<FieldVisit, Long> {
    List<FieldVisit> findByContractIdOrderByVisitDateDesc(Long contractId);
    List<FieldVisit> findAllByOrderByVisitDateDesc();
}
