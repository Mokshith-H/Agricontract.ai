package com.agri.contractfarming.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "sowing_advisory_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class SowingAdvisoryLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "contract_id", nullable = false)
    @JsonIgnoreProperties({"advisoryLogs", "fieldVisits", "procurementRecords", "paymentMilestones", "hibernateLazyInitializer", "handler"})
    private Contract contract;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private AdvisoryStage stage;

    @Column(nullable = false)
    private LocalDate scheduledDate;

    private LocalDate actualDate;

    @Column(nullable = false, length = 1000)
    private String advisoryText;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private ComplianceStatus complianceStatus;
}
