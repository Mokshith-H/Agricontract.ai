package com.agri.contractfarming.service;

import com.agri.contractfarming.dto.AgentChatResponseDTO;
import com.agri.contractfarming.dto.AuditResultDTO;
import com.agri.contractfarming.model.*;
import com.agri.contractfarming.repository.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ContractAgentService {

    private static final Logger log = LoggerFactory.getLogger(ContractAgentService.class);

    private final ContractRepository contractRepository;
    private final SowingAdvisoryLogRepository advisoryLogRepository;
    private final FieldVisitRepository fieldVisitRepository;
    private final ProcurementRecordRepository procurementRecordRepository;
    private final PaymentMilestoneRepository paymentMilestoneRepository;
    private final AgentActionLogRepository agentActionLogRepository;

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(6))
            .build();

    /**
     * Executes autonomous audit across all active and at-risk contracts.
     * Evaluates sowing windows, field visit crop health, pest alerts,
     * delivery fulfillment, and automatically unlocks eligible payment milestones.
     */
    @Transactional
    public AuditResultDTO runAutonomousAudit() {
        log.info("Agentic AI: Starting autonomous contract-farming audit scan...");
        List<Contract> contracts = contractRepository.findAll();
        LocalDate today = LocalDate.now();

        int flaggedRiskCount = 0;
        int unlockedMilestonesCount = 0;
        int advisoriesGeneratedCount = 0;
        List<AgentActionLog> newLogs = new ArrayList<>();

        for (Contract contract : contracts) {
            if (contract.getStatus() == ContractStatus.COMPLETED) {
                continue;
            }

            boolean needsRiskStatus = false;
            StringBuilder riskReasons = new StringBuilder();

            // 1. SOWING & AGRONOMIC COMPLIANCE AUDIT
            // Check if sowing period has passed but no sowing advisory is marked COMPLIANT
            List<SowingAdvisoryLog> sowingLogs = advisoryLogRepository.findByContractId(contract.getId());
            boolean sowingVerified = sowingLogs.stream().anyMatch(l -> 
                l.getStage() == AdvisoryStage.SOWING && l.getComplianceStatus() == ComplianceStatus.COMPLIANT);

            if (!sowingVerified && today.isAfter(contract.getSowingEndDate())) {
                needsRiskStatus = true;
                riskReasons.append("Sowing window closed on ")
                        .append(contract.getSowingEndDate())
                        .append(" without verified sowing compliance. ");
            }

            // 2. FIELD VISIT HEALTH & PEST AUDIT
            List<FieldVisit> visits = fieldVisitRepository.findByContractIdOrderByVisitDateDesc(contract.getId());
            if (!visits.isEmpty()) {
                FieldVisit latestVisit = visits.get(0);
                if (latestVisit.getPestAlert()) {
                    needsRiskStatus = true;
                    riskReasons.append("Active pest infestation detected during officer visit (")
                            .append(latestVisit.getRemarks() != null ? latestVisit.getRemarks() : "Pest Alert")
                            .append("). ");
                }
                if (latestVisit.getCropHealthScore() != null && latestVisit.getCropHealthScore() < 6) {
                    needsRiskStatus = true;
                    riskReasons.append("Sub-optimal crop vigor score (")
                            .append(latestVisit.getCropHealthScore())
                            .append("/10). ");
                }
            }

            // Update Contract status if flagged
            if (needsRiskStatus && contract.getStatus() != ContractStatus.AT_RISK) {
                contract.setStatus(ContractStatus.AT_RISK);
                contractRepository.save(contract);
                flaggedRiskCount++;

                AgentActionLog actionLog = AgentActionLog.builder()
                        .contractCode(contract.getContractCode())
                        .agentName("Sowing & Compliance Auditor")
                        .actionType("RISK_FLAGGED")
                        .reasoning("Contract flagged AT_RISK: " + riskReasons.toString())
                        .severity(LogSeverity.WARNING)
                        .timestamp(LocalDateTime.now())
                        .build();
                newLogs.add(agentActionLogRepository.save(actionLog));

                // Auto-generate corrective agronomic advisory if needed
                boolean hasRecentCorrectiveAdvisory = sowingLogs.stream()
                        .anyMatch(a -> a.getAdvisoryText().contains("Corrective Intervention"));
                if (!hasRecentCorrectiveAdvisory) {
                    SowingAdvisoryLog correctiveLog = SowingAdvisoryLog.builder()
                            .contract(contract)
                            .stage(AdvisoryStage.PEST_CONTROL)
                            .scheduledDate(today.plusDays(3))
                            .advisoryText("AI Corrective Intervention: Inspect for stem borer/fungal infestation. Apply organic bio-fungicide & regulate irrigation.")
                            .complianceStatus(ComplianceStatus.PENDING)
                            .build();
                    advisoryLogRepository.save(correctiveLog);
                    advisoriesGeneratedCount++;
                }
            } else if (!needsRiskStatus && contract.getStatus() == ContractStatus.AT_RISK) {
                // If previously AT_RISK but issues resolved, restore to ACTIVE
                contract.setStatus(ContractStatus.ACTIVE);
                contractRepository.save(contract);

                AgentActionLog restoredLog = AgentActionLog.builder()
                        .contractCode(contract.getContractCode())
                        .agentName("Sowing & Compliance Auditor")
                        .actionType("RISK_RESOLVED")
                        .reasoning("Field visits and agronomic checks show healthy conditions; restored to ACTIVE status.")
                        .severity(LogSeverity.INFO)
                        .timestamp(LocalDateTime.now())
                        .build();
                newLogs.add(agentActionLogRepository.save(restoredLog));
            }

            // 3. PROCUREMENT & YIELD RECONCILIATION
            BigDecimal deliveredTons = procurementRecordRepository.sumDeliveredTonsByContractId(contract.getId());
            if (deliveredTons == null) deliveredTons = BigDecimal.ZERO;

            double fulfillmentRatio = contract.getExpectedYieldTons().compareTo(BigDecimal.ZERO) > 0 ?
                    deliveredTons.doubleValue() / contract.getExpectedYieldTons().doubleValue() : 0.0;

            if (fulfillmentRatio >= 1.0 && contract.getStatus() != ContractStatus.COMPLETED) {
                contract.setStatus(ContractStatus.COMPLETED);
                contractRepository.save(contract);

                AgentActionLog completeLog = AgentActionLog.builder()
                        .contractCode(contract.getContractCode())
                        .agentName("Procurement & Yield Reconciler")
                        .actionType("CONTRACT_COMPLETED")
                        .reasoning("Harvest procurement fully satisfied (" + deliveredTons + " / " + contract.getExpectedYieldTons() + " Tons delivered).")
                        .severity(LogSeverity.INFO)
                        .timestamp(LocalDateTime.now())
                        .build();
                newLogs.add(agentActionLogRepository.save(completeLog));
            }

            // 4. AUTOMATED PAYMENT MILESTONE TRIGGER
            List<PaymentMilestone> milestones = paymentMilestoneRepository.findByContractId(contract.getId());
            for (PaymentMilestone milestone : milestones) {
                if (milestone.getStatus() == MilestoneStatus.LOCKED) {
                    boolean unlock = false;
                    String triggerReason = "";

                    String condition = milestone.getTriggerCondition().toLowerCase();
                    if (condition.contains("sowing") || condition.contains("stage 1") || condition.contains("mobilization")) {
                        // Sowing stage completed
                        boolean sowingPassed = sowingLogs.stream().anyMatch(l -> 
                            l.getComplianceStatus() == ComplianceStatus.COMPLIANT);
                        if (sowingPassed) {
                            unlock = true;
                            triggerReason = "Verified sowing compliance and field preparation approved.";
                        }
                    } else if (condition.contains("50%") || condition.contains("interim delivery") || condition.contains("mid")) {
                        if (fulfillmentRatio >= 0.50) {
                            unlock = true;
                            triggerReason = "50% harvest delivery target achieved (" + String.format("%.1f", fulfillmentRatio * 100) + "%).";
                        }
                    } else if (condition.contains("final") || condition.contains("100%") || condition.contains("settlement")) {
                        if (fulfillmentRatio >= 0.95) {
                            unlock = true;
                            triggerReason = "Procurement delivery fully reconciled and verified.";
                        }
                    }

                    if (unlock) {
                        milestone.setStatus(MilestoneStatus.ELIGIBLE);
                        milestone.setUpdatedAt(LocalDateTime.now());
                        paymentMilestoneRepository.save(milestone);
                        unlockedMilestonesCount++;

                        AgentActionLog unlockLog = AgentActionLog.builder()
                                .contractCode(contract.getContractCode())
                                .agentName("Milestone Payment Trigger")
                                .actionType("MILESTONE_UNLOCKED")
                                .reasoning("Milestone '" + milestone.getMilestoneTitle() + "' unlocked to ELIGIBLE: " + triggerReason)
                                .severity(LogSeverity.INFO)
                                .timestamp(LocalDateTime.now())
                                .build();
                        newLogs.add(agentActionLogRepository.save(unlockLog));
                    }
                }
            }
        }

        // Global audit log entry
        AgentActionLog summaryLog = AgentActionLog.builder()
                .contractCode("ALL")
                .agentName("Autonomous System Orchestrator")
                .actionType("AUDIT_COMPLETED")
                .reasoning(String.format("Autonomous audit scan complete. Processed %d contracts, flagged %d at-risk, unlocked %d payment milestones.",
                        contracts.size(), flaggedRiskCount, unlockedMilestonesCount))
                .severity(flaggedRiskCount > 0 ? LogSeverity.WARNING : LogSeverity.INFO)
                .timestamp(LocalDateTime.now())
                .build();
        newLogs.add(agentActionLogRepository.save(summaryLog));

        return AuditResultDTO.builder()
                .auditedContractsCount(contracts.size())
                .flaggedRiskCount(flaggedRiskCount)
                .unlockedMilestonesCount(unlockedMilestonesCount)
                .advisoriesGeneratedCount(advisoriesGeneratedCount)
                .message("Autonomous contract audit finished successfully.")
                .triggeredLogs(newLogs)
                .build();
    }

    /**
     * Triggered on new Field Visit submission.
     * Evaluates pest alert and health score immediately.
     */
    @Transactional
    public void evaluateFieldVisit(FieldVisit visit) {
        Contract contract = visit.getContract();
        if (contract == null) return;

        boolean isHighRisk = visit.getPestAlert() || (visit.getCropHealthScore() != null && visit.getCropHealthScore() < 6);

        if (isHighRisk) {
            contract.setStatus(ContractStatus.AT_RISK);
            contractRepository.save(contract);

            String reason = String.format("Field visit by %s alerted risk: Health Score=%d/10, PestAlert=%b. Remarks: %s",
                    visit.getOfficerName(), visit.getCropHealthScore(), visit.getPestAlert(), visit.getRemarks());

            AgentActionLog logEntry = AgentActionLog.builder()
                    .contractCode(contract.getContractCode())
                    .agentName("Sowing & Compliance Auditor")
                    .actionType("FIELD_VISIT_RISK_TRIGGER")
                    .reasoning(reason)
                    .severity(LogSeverity.CRITICAL)
                    .timestamp(LocalDateTime.now())
                    .build();
            agentActionLogRepository.save(logEntry);

            // Auto-schedule an urgent intervention advisory
            SowingAdvisoryLog alertAdvisory = SowingAdvisoryLog.builder()
                    .contract(contract)
                    .stage(AdvisoryStage.PEST_CONTROL)
                    .scheduledDate(LocalDate.now().plusDays(2))
                    .advisoryText("URGENT REMEDIATION: Pest alert detected by field officer " + visit.getOfficerName() + 
                            ". Apply recommended neem oil emulsion/chlorantraniliprole within 48h.")
                    .complianceStatus(ComplianceStatus.PENDING)
                    .build();
            advisoryLogRepository.save(alertAdvisory);
        } else {
            AgentActionLog logEntry = AgentActionLog.builder()
                    .contractCode(contract.getContractCode())
                    .agentName("Sowing & Compliance Auditor")
                    .actionType("FIELD_VISIT_APPROVED")
                    .reasoning(String.format("Healthy field visit recorded by %s (Score: %d/10). Moisture: %s.",
                            visit.getOfficerName(), visit.getCropHealthScore(), visit.getSoilMoisture()))
                    .severity(LogSeverity.INFO)
                    .timestamp(LocalDateTime.now())
                    .build();
            agentActionLogRepository.save(logEntry);
        }
    }

    /**
     * Triggered on new Procurement Record delivery.
     * Reconciles delivered yield against expectations and auto-triggers milestone payments.
     */
    @Transactional
    public void evaluateProcurement(ProcurementRecord record) {
        Contract contract = record.getContract();
        if (contract == null) return;

        BigDecimal totalDelivered = procurementRecordRepository.sumDeliveredTonsByContractId(contract.getId());
        if (totalDelivered == null) totalDelivered = record.getDeliveredTons();

        BigDecimal expected = contract.getExpectedYieldTons();
        double ratio = expected.compareTo(BigDecimal.ZERO) > 0 ?
                totalDelivered.doubleValue() / expected.doubleValue() : 0.0;

        String deliveryNote = String.format("Procurement of %.2f Tons (Grade: %s, Rcpt: %s). Total now: %.2f / %.2f Tons (%.1f%%).",
                record.getDeliveredTons(), record.getQualityGrade(), record.getReceiptNumber(),
                totalDelivered, expected, ratio * 100);

        AgentActionLog logEntry = AgentActionLog.builder()
                .contractCode(contract.getContractCode())
                .agentName("Procurement & Yield Reconciler")
                .actionType("DELIVERY_LOGGED")
                .reasoning(deliveryNote)
                .severity(LogSeverity.INFO)
                .timestamp(LocalDateTime.now())
                .build();
        agentActionLogRepository.save(logEntry);

        // Check if milestone unlocked
        List<PaymentMilestone> milestones = paymentMilestoneRepository.findByContractId(contract.getId());
        for (PaymentMilestone m : milestones) {
            if (m.getStatus() == MilestoneStatus.LOCKED) {
                String cond = m.getTriggerCondition().toLowerCase();
                if ((cond.contains("50%") && ratio >= 0.50) || (cond.contains("final") && ratio >= 0.95)) {
                    m.setStatus(MilestoneStatus.ELIGIBLE);
                    m.setUpdatedAt(LocalDateTime.now());
                    paymentMilestoneRepository.save(m);

                    AgentActionLog unlockLog = AgentActionLog.builder()
                            .contractCode(contract.getContractCode())
                            .agentName("Milestone Payment Trigger")
                            .actionType("MILESTONE_UNLOCKED")
                            .reasoning(String.format("Delivery unlocked milestone '%s' for $%.2f.", m.getMilestoneTitle(), m.getAmount()))
                            .severity(LogSeverity.INFO)
                            .timestamp(LocalDateTime.now())
                            .build();
                    agentActionLogRepository.save(unlockLog);
                }
            }
        }

        if (ratio >= 1.0) {
            contract.setStatus(ContractStatus.COMPLETED);
            contractRepository.save(contract);
        }
    }

    /**
     * Natural Language Copilot Chat Engine.
     * Integrates live DB context and falls back to a comprehensive agri-rule engine
     * if external LLM API key is not present.
     */
    public AgentChatResponseDTO processCopilotChat(String userQuery) {
        if (userQuery == null || userQuery.isBlank()) {
            return AgentChatResponseDTO.builder()
                    .reply("Hello! I am your Contract-Farming Agentic Copilot. You can ask me about at-risk contracts, sowing compliance, harvest procurements, or pending payment milestones.")
                    .timestamp(LocalDateTime.now())
                    .agentName("Contract-Farming Copilot")
                    .suggestedActions(List.of("Which contracts are at risk?", "Show pending payment milestones", "What is overall sowing compliance?", "Run autonomous audit scan"))
                    .reasoningContext("Standard greeting trigger.")
                    .build();
        }

        String queryLower = userQuery.toLowerCase().trim();

        // Check if LLM API key is available in environment
        String geminiApiKey = System.getenv("GEMINI_API_KEY");
        String openaiApiKey = System.getenv("OPENAI_API_KEY");

        if (geminiApiKey != null && !geminiApiKey.isBlank()) {
            try {
                return callGeminiLLM(userQuery, geminiApiKey);
            } catch (Exception e) {
                log.warn("Gemini LLM call failed or timed out, falling back to rule engine: {}", e.getMessage());
            }
        } else if (openaiApiKey != null && !openaiApiKey.isBlank()) {
            try {
                return callOpenAILLM(userQuery, openaiApiKey);
            } catch (Exception e) {
                log.warn("OpenAI LLM call failed or timed out, falling back to rule engine: {}", e.getMessage());
            }
        }

        // SMART DETERMINISTIC RULE ENGINE WITH REAL-TIME DATABASE CONTEXT
        return executeDeterministicRuleCopilot(queryLower, userQuery);
    }

    private AgentChatResponseDTO executeDeterministicRuleCopilot(String queryLower, String originalQuery) {
        List<Contract> contracts = contractRepository.findAll();
        List<Contract> atRisk = contracts.stream().filter(c -> c.getStatus() == ContractStatus.AT_RISK).toList();
        List<PaymentMilestone> eligibleMilestones = paymentMilestoneRepository.findByStatus(MilestoneStatus.ELIGIBLE);
        List<PaymentMilestone> lockedMilestones = paymentMilestoneRepository.findByStatus(MilestoneStatus.LOCKED);
        List<PaymentMilestone> approvedMilestones = paymentMilestoneRepository.findByStatus(MilestoneStatus.APPROVED);

        BigDecimal totalCommitted = contracts.stream()
                .map(Contract::getExpectedYieldTons)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalDelivered = procurementRecordRepository.sumTotalDeliveredTons();
        if (totalDelivered == null) totalDelivered = BigDecimal.ZERO;

        long compliantLogs = advisoryLogRepository.countByComplianceStatus(ComplianceStatus.COMPLIANT);
        long totalLogs = advisoryLogRepository.count();
        double complianceRate = totalLogs > 0 ? (compliantLogs * 100.0) / totalLogs : 100.0;

        StringBuilder reply = new StringBuilder();
        List<String> suggestedActions = new ArrayList<>();
        String context = "Aggregated live JPA repository facts.";

        if (queryLower.contains("risk") || queryLower.contains("problem") || queryLower.contains("issue") || queryLower.contains("danger")) {
            if (atRisk.isEmpty()) {
                reply.append("Great news! Currently, **0 contracts are flagged AT_RISK**. All active contracts have healthy field visit scores and are within sowing timelines.");
                suggestedActions.addAll(List.of("Show pending payment milestones", "Check crop yield fulfillment", "Log a new field visit"));
            } else {
                reply.append(String.format("There are currently **%d contracts flagged AT_RISK**:\n\n", atRisk.size()));
                for (Contract c : atRisk) {
                    reply.append(String.format("• **%s** (%s - %s) | Farmer: **%s** (%s, %s) | Expected: %s Tons.\n",
                            c.getContractCode(), c.getCropType(), c.getVariety(),
                            c.getFarmer().getName(), c.getFarmer().getVillage(), c.getFarmer().getDistrict(),
                            c.getExpectedYieldTons()));
                }
                reply.append("\n*Recommendation:* Schedule priority field visits with bio-pesticide advisory or check overdue sowing logs.");
                suggestedActions.addAll(List.of("Run autonomous audit scan", "View Contracts Table", "Log Field Visit"));
            }
            context = "Evaluated ContractStatus.AT_RISK filters.";

        } else if (queryLower.contains("payment") || queryLower.contains("milestone") || queryLower.contains("payout") || queryLower.contains("disburs")) {
            BigDecimal eligibleSum = paymentMilestoneRepository.sumAmountByStatus(MilestoneStatus.ELIGIBLE);
            if (eligibleSum == null) eligibleSum = BigDecimal.ZERO;
            BigDecimal approvedSum = paymentMilestoneRepository.sumAmountByStatus(MilestoneStatus.APPROVED);
            if (approvedSum == null) approvedSum = BigDecimal.ZERO;

            reply.append(String.format("Here is the Payment Milestone Status:\n\n" +
                    "• **Eligible for Approval:** %d milestone(s) totaling **$%,.2f**\n" +
                    "• **Approved / Pending Disbursal:** %d milestone(s) totaling **$%,.2f**\n" +
                    "• **Locked Milestones:** %d milestone(s) waiting for sowing/harvest triggers\n\n",
                    eligibleMilestones.size(), eligibleSum, approvedMilestones.size(), approvedSum, lockedMilestones.size()));

            if (!eligibleMilestones.isEmpty()) {
                reply.append("Pending Approval Highlights:\n");
                for (int i = 0; i < Math.min(3, eligibleMilestones.size()); i++) {
                    PaymentMilestone m = eligibleMilestones.get(i);
                    reply.append(String.format("- **%s** for Contract %s: **$%,.2f** (Condition: *%s*)\n",
                            m.getMilestoneTitle(), m.getContract().getContractCode(), m.getAmount(), m.getTriggerCondition()));
                }
            }
            suggestedActions.addAll(List.of("Approve all eligible payments", "View Payments Queue", "Check procurement deliveries"));
            context = "Queried PaymentMilestone statuses: ELIGIBLE, APPROVED, LOCKED.";

        } else if (queryLower.contains("compliance") || queryLower.contains("sowing") || queryLower.contains("advisory")) {
            reply.append(String.format("Sowing & Agronomic Compliance stands at **%.1f%%** (%d compliant logs out of %d scheduled advisories).\n\n" +
                    "The autonomous agent checks land prep, sowing window verification, fertilizer scheduling, and pest control stages.",
                    complianceRate, compliantLogs, totalLogs));
            suggestedActions.addAll(List.of("Which contracts are at risk?", "Audit contract sowing windows", "Log harvest delivery"));
            context = "Calculated sowing advisory compliance ratio.";

        } else if (queryLower.contains("yield") || queryLower.contains("procure") || queryLower.contains("delivery") || queryLower.contains("harvest") || queryLower.contains("ton")) {
            double fulfillment = totalCommitted.compareTo(BigDecimal.ZERO) > 0 ?
                    (totalDelivered.doubleValue() / totalCommitted.doubleValue()) * 100 : 0.0;

            reply.append(String.format("Procurement Reconciliation Summary:\n\n" +
                    "• **Committed Target:** %,.1f Tons\n" +
                    "• **Total Delivered to Date:** %,.1f Tons\n" +
                    "• **Overall Fulfillment:** **%.1f%%**\n\n" +
                    "Top crops: Basmati Rice, Sharbati Wheat, Hybrid Tomato, and BT Cotton.",
                    totalCommitted, totalDelivered, fulfillment));
            suggestedActions.addAll(List.of("Log a new harvest delivery", "Show pending payment milestones", "View dashboard charts"));
            context = "Aggregated ProcurementRecord sum against Contract expected yields.";

        } else if (queryLower.contains("audit") || queryLower.contains("scan") || queryLower.contains("check all")) {
            AuditResultDTO auditResult = runAutonomousAudit();
            reply.append(String.format("Autonomous Audit Triggered:\n" +
                    "• Scanned Contracts: **%d**\n" +
                    "• Flagged At-Risk: **%d**\n" +
                    "• Payment Milestones Unlocked: **%d**\n" +
                    "• Advisories Auto-Generated: **%d**\n\n" +
                    "The contract progress dashboard has been synchronized with the latest agronomic and procurement state.",
                    auditResult.getAuditedContractsCount(), auditResult.getFlaggedRiskCount(),
                    auditResult.getUnlockedMilestonesCount(), auditResult.getAdvisoriesGeneratedCount()));
            suggestedActions.addAll(List.of("Which contracts are at risk?", "Show pending payment milestones", "View recent activity logs"));
            context = "Executed runAutonomousAudit() tool workflow.";

        } else {
            // General query response with comprehensive system status
            reply.append(String.format("I am monitoring **%d total farmer contracts** across %s.\n\n" +
                    "• Active & In Progress: **%d** contracts\n" +
                    "• Flagged At-Risk: **%d** contracts\n" +
                    "• Sowing Compliance: **%.1f%%**\n" +
                    "• Procured Harvest: **%,.1f / %,.1f Tons**\n" +
                    "• Ready Payment Disbursals: **%d** milestones\n\n" +
                    "How can I assist you with farmer operations today?",
                    contracts.size(), "Punjab, Haryana, and Maharashtra clusters",
                    contracts.stream().filter(c -> c.getStatus() == ContractStatus.ACTIVE).count(),
                    atRisk.size(), complianceRate, totalDelivered, totalCommitted, eligibleMilestones.size()));
            suggestedActions.addAll(List.of("Which contracts are at risk?", "Show pending payment milestones", "Run autonomous audit scan", "What is overall sowing compliance?"));
            context = "General agricultural status synthesis.";
        }

        return AgentChatResponseDTO.builder()
                .reply(reply.toString())
                .timestamp(LocalDateTime.now())
                .agentName("Contract-Farming Copilot (Autonomous Intelligence)")
                .suggestedActions(suggestedActions)
                .reasoningContext(context)
                .build();
    }

    private AgentChatResponseDTO callGeminiLLM(String query, String apiKey) throws Exception {
        // Prepare prompt with DB stats
        String dbContext = buildDatabasePromptContext();
        String jsonPayload = String.format(
                "{\"contents\": [{\"parts\": [{\"text\": \"You are an AI Agronomist and Contract-Farming Operations Copilot. Use this live DB state to answer: %s\\n\\nUser question: %s\"}]}]}",
                escapeJson(dbContext), escapeJson(query));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .timeout(Duration.ofSeconds(6))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == 200) {
            String body = response.body();
            // Simple text extraction from JSON response
            String marker = "\"text\": \"";
            int idx = body.indexOf(marker);
            if (idx != -1) {
                int endIdx = body.indexOf("\"", idx + marker.length());
                if (endIdx != -1) {
                    String extractedText = body.substring(idx + marker.length(), endIdx)
                            .replace("\\n", "\n")
                            .replace("\\\"", "\"");
                    return AgentChatResponseDTO.builder()
                            .reply(extractedText)
                            .timestamp(LocalDateTime.now())
                            .agentName("Gemini 1.5 Flash Copilot")
                            .suggestedActions(List.of("Which contracts are at risk?", "Show pending payment milestones", "Run autonomous audit scan"))
                            .reasoningContext("Powered by Google Gemini Live API with synchronized DB context.")
                            .build();
                }
            }
        }
        throw new RuntimeException("Gemini returned non-200 or unexpected payload: " + response.statusCode());
    }

    private AgentChatResponseDTO callOpenAILLM(String query, String apiKey) throws Exception {
        String dbContext = buildDatabasePromptContext();
        String jsonPayload = String.format(
                "{\"model\": \"gpt-4o-mini\", \"messages\": [{\"role\": \"system\", \"content\": \"You are an AI Contract-Farming Copilot. DB State: %s\"}, {\"role\": \"user\", \"content\": \"%s\"}]}",
                escapeJson(dbContext), escapeJson(query));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.openai.com/v1/chat/completions"))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .timeout(Duration.ofSeconds(6))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == 200) {
            String body = response.body();
            String marker = "\"content\": \"";
            int idx = body.indexOf(marker);
            if (idx != -1) {
                int endIdx = body.indexOf("\"", idx + marker.length());
                if (endIdx != -1) {
                    String extractedText = body.substring(idx + marker.length(), endIdx)
                            .replace("\\n", "\n")
                            .replace("\\\"", "\"");
                    return AgentChatResponseDTO.builder()
                            .reply(extractedText)
                            .timestamp(LocalDateTime.now())
                            .agentName("OpenAI GPT Copilot")
                            .suggestedActions(List.of("Which contracts are at risk?", "Show pending payment milestones", "Run autonomous audit scan"))
                            .reasoningContext("Powered by OpenAI API with synchronized DB context.")
                            .build();
                }
            }
        }
        throw new RuntimeException("OpenAI returned status: " + response.statusCode());
    }

    private String buildDatabasePromptContext() {
        List<Contract> contracts = contractRepository.findAll();
        long atRisk = contracts.stream().filter(c -> c.getStatus() == ContractStatus.AT_RISK).count();
        BigDecimal totalDelivered = procurementRecordRepository.sumTotalDeliveredTons();
        return String.format("Total contracts: %d, At-Risk contracts: %d, Total harvest delivered: %s Tons.",
                contracts.size(), atRisk, totalDelivered != null ? totalDelivered.toString() : "0");
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
