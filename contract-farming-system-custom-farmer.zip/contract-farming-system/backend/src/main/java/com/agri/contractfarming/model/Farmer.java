package com.agri.contractfarming.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "farmers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Farmer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, length = 20)
    private String phone;

    @Column(nullable = false)
    private String village;

    @Column(nullable = false)
    private String district;

    @Column(length = 100)
    private String state;

    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal totalAcreage;

    @Column(nullable = false)
    private Boolean kycVerified;
}
