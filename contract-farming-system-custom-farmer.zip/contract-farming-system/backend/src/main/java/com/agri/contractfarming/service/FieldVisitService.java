package com.agri.contractfarming.service;

import com.agri.contractfarming.dto.FieldVisitRequestDTO;
import com.agri.contractfarming.model.Contract;
import com.agri.contractfarming.model.FieldVisit;
import com.agri.contractfarming.repository.ContractRepository;
import com.agri.contractfarming.repository.FieldVisitRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FieldVisitService {

    private final FieldVisitRepository fieldVisitRepository;
    private final ContractRepository contractRepository;
    private final ContractAgentService agentService;

    public List<FieldVisit> getAllFieldVisits() {
        return fieldVisitRepository.findAllByOrderByVisitDateDesc();
    }

    public List<FieldVisit> getVisitsByContract(Long contractId) {
        return fieldVisitRepository.findByContractIdOrderByVisitDateDesc(contractId);
    }

    @Transactional
    public FieldVisit recordFieldVisit(FieldVisitRequestDTO dto) {
        Contract contract = contractRepository.findById(dto.getContractId())
                .orElseThrow(() -> new RuntimeException("Contract not found with id: " + dto.getContractId()));

        FieldVisit visit = FieldVisit.builder()
                .contract(contract)
                .officerName(dto.getOfficerName())
                .visitDate(dto.getVisitDate())
                .cropHealthScore(dto.getCropHealthScore())
                .pestAlert(dto.getPestAlert())
                .soilMoisture(dto.getSoilMoisture())
                .remarks(dto.getRemarks())
                .build();

        FieldVisit saved = fieldVisitRepository.save(visit);

        // Autonomous trigger: Sowing & Compliance AI agent immediately evaluates health and pest alert
        agentService.evaluateFieldVisit(saved);

        return saved;
    }
}
