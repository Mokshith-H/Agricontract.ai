package com.agri.contractfarming.repository;

import com.agri.contractfarming.model.MilestoneStatus;
import com.agri.contractfarming.model.PaymentMilestone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface PaymentMilestoneRepository extends JpaRepository<PaymentMilestone, Long> {
    List<PaymentMilestone> findByContractId(Long contractId);
    List<PaymentMilestone> findByStatus(MilestoneStatus status);
    List<PaymentMilestone> findAllByOrderByUpdatedAtDesc();

    @Query("SELECT COALESCE(SUM(m.amount), 0) FROM PaymentMilestone m WHERE m.status = :status")
    BigDecimal sumAmountByStatus(MilestoneStatus status);
}
