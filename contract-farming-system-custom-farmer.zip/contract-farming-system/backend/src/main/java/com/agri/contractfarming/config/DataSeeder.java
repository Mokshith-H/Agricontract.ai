package com.agri.contractfarming.config;

import com.agri.contractfarming.model.*;
import com.agri.contractfarming.repository.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final FarmerRepository farmerRepository;
    private final ContractRepository contractRepository;
    private final SowingAdvisoryLogRepository advisoryLogRepository;
    private final FieldVisitRepository fieldVisitRepository;
    private final ProcurementRecordRepository procurementRecordRepository;
    private final PaymentMilestoneRepository paymentMilestoneRepository;
    private final AgentActionLogRepository agentActionLogRepository;

    @Override
    public void run(String... args) {
        if (farmerRepository.count() > 0) {
            log.info("Database already seeded. Skipping initial data injection.");
            return;
        }

        log.info("Seeding realistic contract-farming entities, advisories, visits, and milestones...");

        // 1. Seed 8 Farmers
        Farmer f1 = farmerRepository.save(Farmer.builder().name("Gurpreet Singh").phone("+91 98765 43210").village("Khanna").district("Ludhiana").totalAcreage(new BigDecimal("25.0")).kycVerified(true).build());
        Farmer f2 = farmerRepository.save(Farmer.builder().name("Harinder Kaur").phone("+91 98765 43211").village("Ajnala").district("Amritsar").totalAcreage(new BigDecimal("32.0")).kycVerified(true).build());
        Farmer f3 = farmerRepository.save(Farmer.builder().name("Rajesh Patil").phone("+91 98765 43212").village("Dindori").district("Nashik").totalAcreage(new BigDecimal("18.0")).kycVerified(true).build());
        Farmer f4 = farmerRepository.save(Farmer.builder().name("Rameshwar Shinde").phone("+91 98765 43213").village("Paithan").district("Aurangabad").totalAcreage(new BigDecimal("15.0")).kycVerified(true).build());
        Farmer f5 = farmerRepository.save(Farmer.builder().name("Vikram Choudhary").phone("+91 98765 43214").village("Nilokheri").district("Karnal").totalAcreage(new BigDecimal("22.0")).kycVerified(true).build());
        Farmer f6 = farmerRepository.save(Farmer.builder().name("Baldev Yadav").phone("+91 98765 43215").village("Meham").district("Rohtak").totalAcreage(new BigDecimal("14.0")).kycVerified(true).build());
        Farmer f7 = farmerRepository.save(Farmer.builder().name("Suresh Deshmukh").phone("+91 98765 43216").village("Baramati").district("Pune").totalAcreage(new BigDecimal("20.0")).kycVerified(true).build());
        Farmer f8 = farmerRepository.save(Farmer.builder().name("Manpreet Brar").phone("+91 98765 43217").village("Talwandi Sabo").district("Bathinda").totalAcreage(new BigDecimal("30.0")).kycVerified(true).build());

        LocalDate now = LocalDate.now();

        // 2. Seed 10 Realistic Contracts across 5 Crops
        // Contract 1: Wheat (Active, growing well)
        Contract c1 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-WHT-1001")
                .farmer(f1)
                .cropType("Wheat")
                .variety("Sharbati Premium")
                .committedAcreage(new BigDecimal("20.0"))
                .expectedYieldTons(new BigDecimal("40.0"))
                .pricePerTon(new BigDecimal("320.00"))
                .sowingStartDate(now.minusDays(45))
                .sowingEndDate(now.minusDays(35))
                .expectedHarvestDate(now.plusDays(75))
                .status(ContractStatus.ACTIVE)
                .build());

        // Contract 2: Basmati Rice (Active, high compliance)
        Contract c2 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-RIC-1002")
                .farmer(f2)
                .cropType("Basmati Rice")
                .variety("Pusa 1121")
                .committedAcreage(new BigDecimal("25.0"))
                .expectedYieldTons(new BigDecimal("50.0"))
                .pricePerTon(new BigDecimal("480.00"))
                .sowingStartDate(now.minusDays(60))
                .sowingEndDate(now.minusDays(50))
                .expectedHarvestDate(now.plusDays(40))
                .status(ContractStatus.ACTIVE)
                .build());

        // Contract 3: Tomato (At-Risk: Pest alert detected)
        Contract c3 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-TOM-1003")
                .farmer(f3)
                .cropType("Tomato")
                .variety("Hybrid US-440")
                .committedAcreage(new BigDecimal("10.0"))
                .expectedYieldTons(new BigDecimal("60.0"))
                .pricePerTon(new BigDecimal("210.00"))
                .sowingStartDate(now.minusDays(30))
                .sowingEndDate(now.minusDays(20))
                .expectedHarvestDate(now.plusDays(50))
                .status(ContractStatus.AT_RISK)
                .build());

        // Contract 4: Cotton (Delayed sowing)
        Contract c4 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-COT-1004")
                .farmer(f4)
                .cropType("Cotton")
                .variety("BT Bollgard II")
                .committedAcreage(new BigDecimal("15.0"))
                .expectedYieldTons(new BigDecimal("25.0"))
                .pricePerTon(new BigDecimal("750.00"))
                .sowingStartDate(now.minusDays(25))
                .sowingEndDate(now.minusDays(10))
                .expectedHarvestDate(now.plusDays(90))
                .status(ContractStatus.DELAYED)
                .build());

        // Contract 5: Soybean (Active, partial delivery)
        Contract c5 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-SOY-1005")
                .farmer(f7)
                .cropType("Soybean")
                .variety("JS-335")
                .committedAcreage(new BigDecimal("18.0"))
                .expectedYieldTons(new BigDecimal("30.0"))
                .pricePerTon(new BigDecimal("440.00"))
                .sowingStartDate(now.minusDays(80))
                .sowingEndDate(now.minusDays(70))
                .expectedHarvestDate(now.plusDays(15))
                .status(ContractStatus.ACTIVE)
                .build());

        // Contract 6: Wheat (Completed, fully procured)
        Contract c6 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-WHT-1006")
                .farmer(f5)
                .cropType("Wheat")
                .variety("HD-2967")
                .committedAcreage(new BigDecimal("15.0"))
                .expectedYieldTons(new BigDecimal("35.0"))
                .pricePerTon(new BigDecimal("310.00"))
                .sowingStartDate(now.minusDays(120))
                .sowingEndDate(now.minusDays(110))
                .expectedHarvestDate(now.minusDays(5))
                .status(ContractStatus.COMPLETED)
                .build());

        // Contract 7: Basmati Rice (Active)
        Contract c7 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-RIC-1007")
                .farmer(f8)
                .cropType("Basmati Rice")
                .variety("Traditional Dehraduni")
                .committedAcreage(new BigDecimal("20.0"))
                .expectedYieldTons(new BigDecimal("38.0"))
                .pricePerTon(new BigDecimal("510.00"))
                .sowingStartDate(now.minusDays(40))
                .sowingEndDate(now.minusDays(30))
                .expectedHarvestDate(now.plusDays(60))
                .status(ContractStatus.ACTIVE)
                .build());

        // Contract 8: Tomato (Active, harvesting stage)
        Contract c8 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-TOM-1008")
                .farmer(f7)
                .cropType("Tomato")
                .variety("Abhinav Table")
                .committedAcreage(new BigDecimal("8.0"))
                .expectedYieldTons(new BigDecimal("48.0"))
                .pricePerTon(new BigDecimal("220.00"))
                .sowingStartDate(now.minusDays(70))
                .sowingEndDate(now.minusDays(60))
                .expectedHarvestDate(now.plusDays(10))
                .status(ContractStatus.ACTIVE)
                .build());

        // Contract 9: Cotton (At-Risk: Whitefly attack)
        Contract c9 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-COT-1009")
                .farmer(f6)
                .cropType("Cotton")
                .variety("RCH-659")
                .committedAcreage(new BigDecimal("12.0"))
                .expectedYieldTons(new BigDecimal("20.0"))
                .pricePerTon(new BigDecimal("740.00"))
                .sowingStartDate(now.minusDays(50))
                .sowingEndDate(now.minusDays(40))
                .expectedHarvestDate(now.plusDays(70))
                .status(ContractStatus.AT_RISK)
                .build());

        // Contract 10: Soybean (Active, early stage)
        Contract c10 = contractRepository.save(Contract.builder()
                .contractCode("AGRI-SOY-1010")
                .farmer(f3)
                .cropType("Soybean")
                .variety("NRC-37")
                .committedAcreage(new BigDecimal("8.0"))
                .expectedYieldTons(new BigDecimal("16.0"))
                .pricePerTon(new BigDecimal("450.00"))
                .sowingStartDate(now.minusDays(15))
                .sowingEndDate(now.minusDays(5))
                .expectedHarvestDate(now.plusDays(85))
                .status(ContractStatus.ACTIVE)
                .build());

        // 3. Seed Sowing Advisory Logs
        // C1 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c1).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(48)).actualDate(now.minusDays(47)).advisoryText("Deep chisel plowing and laser land leveling for optimal water distribution.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c1).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(40)).actualDate(now.minusDays(39)).advisoryText("Sow treated Sharbati seeds at 100 kg/ha using seed-cum-fertilizer drill.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c1).stage(AdvisoryStage.FERTILIZER).scheduledDate(now.minusDays(20)).actualDate(now.minusDays(18)).advisoryText("First top-dressing of Urea (65 kg/acre) following first crown root irrigation.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C2 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c2).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(65)).actualDate(now.minusDays(64)).advisoryText("Puddling of wetland beds and incorporation of green manure (Dhaincha).").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c2).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(55)).actualDate(now.minusDays(54)).advisoryText("Transplant 25-day old nursery seedlings at 20x15 cm hill spacing.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c2).stage(AdvisoryStage.FERTILIZER).scheduledDate(now.minusDays(35)).actualDate(now.minusDays(34)).advisoryText("Apply Zinc Sulfate (10 kg/acre) and basal NPK 12:32:16.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c2).stage(AdvisoryStage.PEST_CONTROL).scheduledDate(now.minusDays(10)).actualDate(now.minusDays(9)).advisoryText("Preventive spray against stem borer and leaf folder using Cartap hydrochloride.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C3 logs (At-Risk: pest issue)
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c3).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(32)).actualDate(now.minusDays(31)).advisoryText("Raised bed preparation with silver-black mulch installation and drip lines.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c3).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(24)).actualDate(now.minusDays(23)).advisoryText("Transplant hybrid tomato saplings with prophylactic drenching of Trichoderma.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c3).stage(AdvisoryStage.PEST_CONTROL).scheduledDate(now.minusDays(8)).actualDate(null).advisoryText("EMERGENCY INTERVENTION: Severe early blight & fruit borer signs. Spray Flubendiamide + Azoxystrobin within 48h.").complianceStatus(ComplianceStatus.NON_COMPLIANT).build());

        // C4 logs (Delayed)
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c4).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(28)).actualDate(now.minusDays(20)).advisoryText("Sub-soiling and ridge furrow formation for cotton taproot penetration.").complianceStatus(ComplianceStatus.DELAYED).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c4).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(15)).actualDate(null).advisoryText("Direct dibbling of BT Cotton hybrid seeds with 90x60 cm geometry.").complianceStatus(ComplianceStatus.PENDING).build());

        // C5 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c5).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(85)).actualDate(now.minusDays(84)).advisoryText("Broadbed furrow system preparation for soybean drainage management.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c5).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(75)).actualDate(now.minusDays(74)).advisoryText("Inoculate JS-335 seeds with Bradyrhizobium japonicum before sowing.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c5).stage(AdvisoryStage.HARVEST).scheduledDate(now.minusDays(5)).actualDate(now.minusDays(4)).advisoryText("Harvest at physiological maturity when 90% pods turn golden brown.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C6 logs (Completed)
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c6).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(125)).actualDate(now.minusDays(124)).advisoryText("Field discing and plowing.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c6).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(115)).actualDate(now.minusDays(114)).advisoryText("Certified HD-2967 sowing.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c6).stage(AdvisoryStage.FERTILIZER).scheduledDate(now.minusDays(80)).actualDate(now.minusDays(79)).advisoryText("Second split of nitrogen fertilizer.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c6).stage(AdvisoryStage.HARVEST).scheduledDate(now.minusDays(15)).actualDate(now.minusDays(14)).advisoryText("Combine harvester threshing at 12% grain moisture.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C7 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c7).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(45)).actualDate(now.minusDays(44)).advisoryText("Laser levelling and seedbed preparation.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c7).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(35)).actualDate(now.minusDays(34)).advisoryText("Nursery transplantation of Dehraduni Basmati.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C8 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c8).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(75)).actualDate(now.minusDays(74)).advisoryText("Staking bamboo trellis installation for table tomatoes.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c8).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(65)).actualDate(now.minusDays(64)).advisoryText("Transplanting seedlings with bio-fertilizer root dip.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C9 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c9).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(55)).actualDate(now.minusDays(54)).advisoryText("Bed preparation and basal potash application.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c9).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(45)).actualDate(now.minusDays(44)).advisoryText("Dibbling cotton seeds.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // C10 logs
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c10).stage(AdvisoryStage.LAND_PREP).scheduledDate(now.minusDays(20)).actualDate(now.minusDays(19)).advisoryText("Seedbed harrowing and weed removal.").complianceStatus(ComplianceStatus.COMPLIANT).build());
        advisoryLogRepository.save(SowingAdvisoryLog.builder().contract(c10).stage(AdvisoryStage.SOWING).scheduledDate(now.minusDays(10)).actualDate(now.minusDays(9)).advisoryText("Rhizobium seed inoculation and sowing.").complianceStatus(ComplianceStatus.COMPLIANT).build());

        // 4. Seed Field Visits
        fieldVisitRepository.save(FieldVisit.builder().contract(c1).officerName("Dr. Alok Verma").visitDate(now.minusDays(12)).cropHealthScore(9).pestAlert(false).soilMoisture("Optimal (24%)").remarks("Vigorous vegetative growth. Crown root formation well-established, no weed pressure.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c2).officerName("Dr. Alok Verma").visitDate(now.minusDays(7)).cropHealthScore(8).pestAlert(false).soilMoisture("Saturated (32%)").remarks("Panicle initiation beginning smoothly. Uniform tiller density per hill.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c3).officerName("Priya Sharma").visitDate(now.minusDays(6)).cropHealthScore(4).pestAlert(true).soilMoisture("Deficient (14%)").remarks("ALERT: Early blight lesions on lower leaves and fruit borer infestation observed in 15% plants. Advised immediate bio-pesticide spray.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c4).officerName("Priya Sharma").visitDate(now.minusDays(9)).cropHealthScore(5).pestAlert(false).soilMoisture("Sub-optimal (16%)").remarks("Sowing delayed due to unseasonal rain. Germination sparse in low-lying sector.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c5).officerName("Arvind Rao").visitDate(now.minusDays(14)).cropHealthScore(8).pestAlert(false).soilMoisture("Optimal (21%)").remarks("Pod development satisfactory. Pods filling solidly with minimal pod blight.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c6).officerName("Dr. Alok Verma").visitDate(now.minusDays(20)).cropHealthScore(9).pestAlert(false).soilMoisture("Dry (11%)").remarks("Crop fully matured for combine harvesting. High grain luster.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c7).officerName("Dr. Alok Verma").visitDate(now.minusDays(8)).cropHealthScore(8).pestAlert(false).soilMoisture("Optimal (26%)").remarks("Tillering stage progressing optimally. No brown planthopper incidence.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c8).officerName("Priya Sharma").visitDate(now.minusDays(5)).cropHealthScore(9).pestAlert(false).soilMoisture("Optimal (23%)").remarks("First picking underway. High brix and uniform redness observed.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c9).officerName("Arvind Rao").visitDate(now.minusDays(4)).cropHealthScore(4).pestAlert(true).soilMoisture("Deficient (12%)").remarks("ALERT: Whitefly honeydew secretion and sooty mold developing on leaves.").build());
        fieldVisitRepository.save(FieldVisit.builder().contract(c10).officerName("Arvind Rao").visitDate(now.minusDays(2)).cropHealthScore(7).pestAlert(false).soilMoisture("Optimal (20%)").remarks("Germination rate at 94%. Seedling vigor strong across all rows.").build());

        // 5. Seed Procurement Deliveries with Payout Amounts
        // C6 (Wheat, completed: 35.0 Tons @ $310 = $10,850 total)
        procurementRecordRepository.save(ProcurementRecord.builder().contract(c6).deliveryDate(now.minusDays(10)).deliveredTons(new BigDecimal("18.50")).qualityGrade(QualityGrade.GRADE_A).receiptNumber("RCPT-WHT-9801").payoutAmount(new BigDecimal("5735.00")).build());
        procurementRecordRepository.save(ProcurementRecord.builder().contract(c6).deliveryDate(now.minusDays(6)).deliveredTons(new BigDecimal("16.50")).qualityGrade(QualityGrade.GRADE_A).receiptNumber("RCPT-WHT-9802").payoutAmount(new BigDecimal("5115.00")).build());

        // C5 (Soybean, partial: 15.0 Tons @ $440 = $6,600)
        procurementRecordRepository.save(ProcurementRecord.builder().contract(c5).deliveryDate(now.minusDays(3)).deliveredTons(new BigDecimal("15.00")).qualityGrade(QualityGrade.GRADE_A).receiptNumber("RCPT-SOY-9803").payoutAmount(new BigDecimal("6600.00")).build());

        // C8 (Tomato, partial: 22.0 Tons @ $220 = $4,840)
        procurementRecordRepository.save(ProcurementRecord.builder().contract(c8).deliveryDate(now.minusDays(2)).deliveredTons(new BigDecimal("22.00")).qualityGrade(QualityGrade.GRADE_B).receiptNumber("RCPT-TOM-9804").payoutAmount(new BigDecimal("4840.00")).build());

        // C1 (Wheat, partial early batch: 10.0 Tons @ $320 = $3,200)
        procurementRecordRepository.save(ProcurementRecord.builder().contract(c1).deliveryDate(now.minusDays(1)).deliveredTons(new BigDecimal("10.00")).qualityGrade(QualityGrade.GRADE_A).receiptNumber("RCPT-WHT-9805").payoutAmount(new BigDecimal("3200.00")).build());

        // 6. Seed Payment Milestones across all 10 contracts
        // C1 Milestones (Wheat)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c1).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("2560.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(35)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c1).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("3840.00")).triggerCondition("Field visit score >= 7 and fertilizer compliance").status(MilestoneStatus.APPROVED).updatedAt(LocalDateTime.now().minusDays(10)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c1).milestoneTitle("Interim Harvest Delivery (25%)").amount(new BigDecimal("3200.00")).triggerCondition("First batch delivery verified").status(MilestoneStatus.ELIGIBLE).updatedAt(LocalDateTime.now().minusDays(1)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c1).milestoneTitle("Final Harvest Reconciliation (25%)").amount(new BigDecimal("3200.00")).triggerCondition("Procurement 100% target verified with Grade A/B").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(45)).build());

        // C2 Milestones (Basmati Rice)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c2).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("4800.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(50)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c2).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("7200.00")).triggerCondition("Field visit score >= 7 and fertilizer compliance").status(MilestoneStatus.ELIGIBLE).updatedAt(LocalDateTime.now().minusDays(5)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c2).milestoneTitle("Final Harvest Reconciliation (50%)").amount(new BigDecimal("12000.00")).triggerCondition("Procurement 100% target verified with Grade A/B").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(60)).build());

        // C3 Milestones (Tomato, At-risk)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c3).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("2520.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(20)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c3).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("3780.00")).triggerCondition("Field visit score >= 7 and fertilizer compliance").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(30)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c3).milestoneTitle("Final Harvest Reconciliation (50%)").amount(new BigDecimal("6300.00")).triggerCondition("Procurement 100% target verified with Grade A/B").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(30)).build());

        // C4 Milestones (Cotton, Delayed)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c4).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("3750.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(25)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c4).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("5625.00")).triggerCondition("Field visit score >= 7").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(25)).build());

        // C5 Milestones (Soybean, 50% delivered)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c5).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("2640.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(70)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c5).milestoneTitle("50% Harvest Delivery Interim Payout (40%)").amount(new BigDecimal("5280.00")).triggerCondition("50% harvest delivery target achieved").status(MilestoneStatus.ELIGIBLE).updatedAt(LocalDateTime.now().minusDays(1)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c5).milestoneTitle("Final Quality Reconciliation (40%)").amount(new BigDecimal("5280.00")).triggerCondition("Procurement 100% target verified with Grade A/B").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(80)).build());

        // C6 Milestones (Wheat, Completed)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c6).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("2170.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(110)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c6).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("3255.00")).triggerCondition("Field visit score >= 7 and fertilizer compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(75)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c6).milestoneTitle("Final Harvest Reconciliation (50%)").amount(new BigDecimal("5425.00")).triggerCondition("Procurement 100% target verified with Grade A/B").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(4)).build());

        // C7 Milestones (Basmati Rice)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c7).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("3876.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(30)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c7).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("5814.00")).triggerCondition("Field visit score >= 7").status(MilestoneStatus.ELIGIBLE).updatedAt(LocalDateTime.now().minusDays(2)).build());

        // C8 Milestones (Tomato)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c8).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("2112.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(60)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c8).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("3168.00")).triggerCondition("Field visit score >= 7").status(MilestoneStatus.APPROVED).updatedAt(LocalDateTime.now().minusDays(15)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c8).milestoneTitle("First Picking Delivery Interim (25%)").amount(new BigDecimal("2640.00")).triggerCondition("Harvest delivery verified").status(MilestoneStatus.ELIGIBLE).updatedAt(LocalDateTime.now().minusDays(1)).build());

        // C9 Milestones (Cotton, At-Risk)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c9).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("2960.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.PAID).updatedAt(LocalDateTime.now().minusDays(40)).build());
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c9).milestoneTitle("Mid-Growth Agronomic Verification (30%)").amount(new BigDecimal("4440.00")).triggerCondition("Field visit score >= 7").status(MilestoneStatus.LOCKED).updatedAt(LocalDateTime.now().minusDays(40)).build());

        // C10 Milestones (Soybean)
        paymentMilestoneRepository.save(PaymentMilestone.builder().contract(c10).milestoneTitle("Advance Sowing Mobilization (20%)").amount(new BigDecimal("1440.00")).triggerCondition("Sowing verification and Land Prep compliance").status(MilestoneStatus.ELIGIBLE).updatedAt(LocalDateTime.now().minusDays(1)).build());

        // 7. Seed Initial Agent Action Logs across multiple contracts
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-TOM-1003").agentName("Sowing & Compliance Auditor").actionType("RISK_FLAGGED").reasoning("Contract flagged AT_RISK: Field visit alerted active fruit borer and early blight infestation (Score: 4/10). Urgent bio-fungicide advisory dispatched.").severity(LogSeverity.CRITICAL).timestamp(LocalDateTime.now().minusDays(6)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-COT-1009").agentName("Sowing & Compliance Auditor").actionType("RISK_FLAGGED").reasoning("Contract flagged AT_RISK: Sub-optimal soil moisture (12%) and whitefly infestation alert registered by field agronomist.").severity(LogSeverity.WARNING).timestamp(LocalDateTime.now().minusDays(4)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-SOY-1005").agentName("Milestone Payment Trigger").actionType("MILESTONE_UNLOCKED").reasoning("Delivery of 15.0 Tons achieved 50% threshold. Interim milestone '$5,280.00' unlocked to ELIGIBLE status.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusDays(1)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-WHT-1006").agentName("Procurement & Yield Reconciler").actionType("CONTRACT_COMPLETED").reasoning("Harvest procurement fully satisfied (35.0 / 35.0 Tons delivered with Grade A). Contract transitioned to COMPLETED.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusDays(5)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-RIC-1002").agentName("Sowing & Compliance Auditor").actionType("ADVISORY_COMPLIANT").reasoning("Field visit confirmed optimal panicle health (Score: 8/10). Mid-growth milestone '$7,200.00' unlocked to ELIGIBLE.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusDays(5)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-WHT-1001").agentName("Milestone Payment Trigger").actionType("MILESTONE_UNLOCKED").reasoning("First batch procurement of 10.0 Tons verified. Interim milestone '$3,200.00' unlocked to ELIGIBLE.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusDays(1)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-TOM-1008").agentName("Milestone Payment Trigger").actionType("MILESTONE_UNLOCKED").reasoning("Delivery of 22.0 Tons recorded. Interim payout '$2,640.00' unlocked to ELIGIBLE.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusDays(1)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-RIC-1007").agentName("Sowing & Compliance Auditor").actionType("STAGE_VERIFIED").reasoning("Field visit confirms tillering vigor score 8/10. Milestone '$5,814.00' unlocked to ELIGIBLE.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusDays(2)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("AGRI-COT-1004").agentName("Sowing & Compliance Auditor").actionType("DELAY_FLAGGED").reasoning("Sowing timeline delayed past target window due to unseasonal rainfall. Agronomist intervention advised.").severity(LogSeverity.WARNING).timestamp(LocalDateTime.now().minusDays(9)).build());
        agentActionLogRepository.save(AgentActionLog.builder().contractCode("ALL").agentName("Autonomous System Orchestrator").actionType("AUDIT_COMPLETED").reasoning("Routine autonomous audit completed. 10 contracts surveyed, 2 flagged at-risk, 5 payment milestones unlocked to ELIGIBLE.").severity(LogSeverity.INFO).timestamp(LocalDateTime.now().minusMinutes(30)).build());

        log.info("Contract-farming database seeding completed successfully.");
    }
}
