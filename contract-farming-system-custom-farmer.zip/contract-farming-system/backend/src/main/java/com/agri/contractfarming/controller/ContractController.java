package com.agri.contractfarming.controller;

import com.agri.contractfarming.dto.ContractCreateRequestDTO;
import com.agri.contractfarming.dto.ContractDetailDTO;
import com.agri.contractfarming.model.Contract;
import com.agri.contractfarming.service.ContractService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/contracts")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ContractController {

    private final ContractService contractService;

    @GetMapping
    public ResponseEntity<List<Contract>> getAllContracts() {
        return ResponseEntity.ok(contractService.getAllContracts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ContractDetailDTO> getContractById(@PathVariable Long id) {
        return ResponseEntity.ok(contractService.getContractDetails(id));
    }

    @GetMapping("/{id}/details")
    public ResponseEntity<ContractDetailDTO> getContractDetails(@PathVariable Long id) {
        return ResponseEntity.ok(contractService.getContractDetails(id));
    }

    @PostMapping
    public ResponseEntity<Contract> createContract(@Valid @RequestBody ContractCreateRequestDTO dto) {
        return new ResponseEntity<>(contractService.createContract(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Contract> updateContract(@PathVariable Long id, @RequestBody Contract contract) {
        return ResponseEntity.ok(contractService.updateContract(id, contract));
    }
}
