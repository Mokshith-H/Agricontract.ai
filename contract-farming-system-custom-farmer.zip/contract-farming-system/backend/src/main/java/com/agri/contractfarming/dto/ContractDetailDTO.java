package com.agri.contractfarming.dto;

import com.agri.contractfarming.model.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContractDetailDTO {
    private Long id;
    private String contractCode;
    private Long farmerId;
    private String farmerName;
    private String farmerPhone;
    private String farmerVillage;
    private String farmerDistrict;
    private Boolean kycVerified;

    private String cropType;
    private String variety;
    private BigDecimal committedAcreage;
    private BigDecimal expectedYieldTons;
    private BigDecimal deliveredYieldTons;
    private BigDecimal pricePerTon;
    private BigDecimal totalContractValue;
    private LocalDate sowingStartDate;
    private LocalDate sowingEndDate;
    private LocalDate expectedHarvestDate;
    private ContractStatus status;

    private int lifecycleStage; // 1: Signed, 2: Sowing Verified, 3: Advisory Compliant, 4: Harvest Delivered, 5: Settled
    private String lifecycleStageName;
    private String aiRiskNotes;

    private List<AdvisoryLogItemDTO> advisoryLogs;
    private List<FieldVisitItemDTO> fieldVisits;
    private List<ProcurementItemDTO> procurementRecords;
    private List<PaymentMilestoneItemDTO> paymentMilestones;
    private List<AgentLogItemDTO> agentLogs;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AdvisoryLogItemDTO {
        private Long id;
        private AdvisoryStage stage;
        private LocalDate scheduledDate;
        private LocalDate actualDate;
        private String advisoryText;
        private ComplianceStatus complianceStatus;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class FieldVisitItemDTO {
        private Long id;
        private String officerName;
        private LocalDate visitDate;
        private Integer cropHealthScore;
        private Boolean pestAlert;
        private String soilMoisture;
        private String remarks;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ProcurementItemDTO {
        private Long id;
        private LocalDate deliveryDate;
        private BigDecimal deliveredTons;
        private QualityGrade qualityGrade;
        private String receiptNumber;
        private BigDecimal payoutAmount;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PaymentMilestoneItemDTO {
        private Long id;
        private String milestoneTitle;
        private BigDecimal amount;
        private String triggerCondition;
        private MilestoneStatus status;
        private LocalDateTime updatedAt;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AgentLogItemDTO {
        private Long id;
        private String contractCode;
        private String agentName;
        private String actionType;
        private String reasoning;
        private LogSeverity severity;
        private LocalDateTime timestamp;
    }
}
