package com.agri.contractfarming.controller;

import com.agri.contractfarming.dto.AgentChatRequestDTO;
import com.agri.contractfarming.dto.AgentChatResponseDTO;
import com.agri.contractfarming.dto.AuditResultDTO;
import com.agri.contractfarming.model.AgentActionLog;
import com.agri.contractfarming.repository.AgentActionLogRepository;
import com.agri.contractfarming.service.ContractAgentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/agent")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AgentController {

    private final ContractAgentService agentService;
    private final AgentActionLogRepository actionLogRepository;

    @PostMapping("/run-audit")
    public ResponseEntity<AuditResultDTO> runAudit() {
        return ResponseEntity.ok(agentService.runAutonomousAudit());
    }

    @PostMapping("/chat")
    public ResponseEntity<AgentChatResponseDTO> chat(@RequestBody AgentChatRequestDTO request) {
        return ResponseEntity.ok(agentService.processCopilotChat(request.getMessage()));
    }

    @GetMapping("/logs")
    public ResponseEntity<List<AgentActionLog>> getRecentLogs() {
        return ResponseEntity.ok(actionLogRepository.findTop20ByOrderByTimestampDesc());
    }
}
