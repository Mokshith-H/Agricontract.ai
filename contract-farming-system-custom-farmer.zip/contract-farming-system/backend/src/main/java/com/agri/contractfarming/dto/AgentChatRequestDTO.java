package com.agri.contractfarming.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentChatRequestDTO {
    private String message;
}
