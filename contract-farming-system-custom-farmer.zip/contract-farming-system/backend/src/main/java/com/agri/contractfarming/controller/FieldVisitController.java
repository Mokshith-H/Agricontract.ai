package com.agri.contractfarming.controller;

import com.agri.contractfarming.dto.FieldVisitRequestDTO;
import com.agri.contractfarming.model.FieldVisit;
import com.agri.contractfarming.service.FieldVisitService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/field-visits")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FieldVisitController {

    private final FieldVisitService fieldVisitService;

    @GetMapping
    public ResponseEntity<List<FieldVisit>> getAllFieldVisits() {
        return ResponseEntity.ok(fieldVisitService.getAllFieldVisits());
    }

    @GetMapping("/contract/{contractId}")
    public ResponseEntity<List<FieldVisit>> getVisitsByContract(@PathVariable Long contractId) {
        return ResponseEntity.ok(fieldVisitService.getVisitsByContract(contractId));
    }

    @PostMapping
    public ResponseEntity<FieldVisit> recordFieldVisit(@Valid @RequestBody FieldVisitRequestDTO dto) {
        return new ResponseEntity<>(fieldVisitService.recordFieldVisit(dto), HttpStatus.CREATED);
    }
}
