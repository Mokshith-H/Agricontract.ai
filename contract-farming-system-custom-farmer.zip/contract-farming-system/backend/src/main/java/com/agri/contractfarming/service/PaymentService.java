package com.agri.contractfarming.service;

import com.agri.contractfarming.model.AgentActionLog;
import com.agri.contractfarming.model.LogSeverity;
import com.agri.contractfarming.model.MilestoneStatus;
import com.agri.contractfarming.model.PaymentMilestone;
import com.agri.contractfarming.repository.AgentActionLogRepository;
import com.agri.contractfarming.repository.PaymentMilestoneRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentMilestoneRepository paymentMilestoneRepository;
    private final AgentActionLogRepository agentActionLogRepository;

    public List<PaymentMilestone> getAllPayments() {
        return paymentMilestoneRepository.findAllByOrderByUpdatedAtDesc();
    }

    public List<PaymentMilestone> getPaymentsByContract(Long contractId) {
        return paymentMilestoneRepository.findByContractId(contractId);
    }

    @Transactional
    public PaymentMilestone unlockPayment(Long id) {
        PaymentMilestone milestone = paymentMilestoneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment milestone not found with id: " + id));

        milestone.setStatus(MilestoneStatus.ELIGIBLE);
        milestone.setUpdatedAt(LocalDateTime.now());
        PaymentMilestone updated = paymentMilestoneRepository.save(milestone);

        AgentActionLog log = AgentActionLog.builder()
                .contractCode(milestone.getContract().getContractCode())
                .agentName("Payment Disbursement Gateway")
                .actionType("MILESTONE_UNLOCKED")
                .reasoning(String.format("Payment milestone '%s' for $%,.2f manually unlocked to ELIGIBLE by Agri-Finance Officer.",
                        milestone.getMilestoneTitle(), milestone.getAmount()))
                .severity(LogSeverity.INFO)
                .timestamp(LocalDateTime.now())
                .build();
        agentActionLogRepository.save(log);

        return updated;
    }

    @Transactional
    public PaymentMilestone approvePayment(Long id) {
        PaymentMilestone milestone = paymentMilestoneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment milestone not found with id: " + id));

        milestone.setStatus(MilestoneStatus.APPROVED);
        milestone.setUpdatedAt(LocalDateTime.now());
        PaymentMilestone updated = paymentMilestoneRepository.save(milestone);

        AgentActionLog log = AgentActionLog.builder()
                .contractCode(milestone.getContract().getContractCode())
                .agentName("Payment Disbursement Gateway")
                .actionType("PAYMENT_APPROVED")
                .reasoning(String.format("Payment milestone '%s' for $%,.2f manually approved by Agri-Finance Officer.",
                        milestone.getMilestoneTitle(), milestone.getAmount()))
                .severity(LogSeverity.INFO)
                .timestamp(LocalDateTime.now())
                .build();
        agentActionLogRepository.save(log);

        return updated;
    }

    @Transactional
    public PaymentMilestone markAsPaid(Long id) {
        PaymentMilestone milestone = paymentMilestoneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment milestone not found with id: " + id));

        milestone.setStatus(MilestoneStatus.PAID);
        milestone.setUpdatedAt(LocalDateTime.now());
        return paymentMilestoneRepository.save(milestone);
    }
}
