package com.agri.contractfarming.model;

public enum QualityGrade {
    GRADE_A,
    GRADE_B,
    REJECTED
}
