package com.agri.contractfarming.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContractCreateRequestDTO {
    @NotNull(message = "Farmer ID is required")
    private Long farmerId;

    @NotNull(message = "Crop type is required")
    private String cropType;

    @NotNull(message = "Variety is required")
    private String variety;

    @NotNull(message = "Committed acreage is required")
    @Positive
    private BigDecimal committedAcreage;

    @NotNull(message = "Expected yield is required")
    @Positive
    private BigDecimal expectedYieldTons;

    @NotNull(message = "Price per ton is required")
    @Positive
    private BigDecimal pricePerTon;

    @NotNull(message = "Sowing start date is required")
    private LocalDate sowingStartDate;

    @NotNull(message = "Sowing end date is required")
    private LocalDate sowingEndDate;

    @NotNull(message = "Expected harvest date is required")
    private LocalDate expectedHarvestDate;
}
