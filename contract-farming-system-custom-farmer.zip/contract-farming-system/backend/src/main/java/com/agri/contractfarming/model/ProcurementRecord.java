package com.agri.contractfarming.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "procurement_records")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ProcurementRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "contract_id", nullable = false)
    @JsonIgnoreProperties({"advisoryLogs", "fieldVisits", "procurementRecords", "paymentMilestones", "hibernateLazyInitializer", "handler"})
    private Contract contract;

    @Column(nullable = false)
    private LocalDate deliveryDate;

    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal deliveredTons;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private QualityGrade qualityGrade;

    @Column(nullable = false, unique = true, length = 50)
    private String receiptNumber;

    @Column(precision = 12, scale = 2)
    private BigDecimal payoutAmount;
}
