package com.agri.contractfarming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ContractFarmingApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContractFarmingApplication.class, args);
    }
}
