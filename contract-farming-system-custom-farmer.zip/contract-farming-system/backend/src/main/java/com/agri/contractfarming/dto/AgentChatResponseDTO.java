package com.agri.contractfarming.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentChatResponseDTO {
    private String reply;
    private LocalDateTime timestamp;
    private String agentName;
    private List<String> suggestedActions;
    private String reasoningContext;
}
