package com.agri.contractfarming.service;

import com.agri.contractfarming.dto.DashboardSummaryDTO;
import com.agri.contractfarming.model.*;
import com.agri.contractfarming.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final ContractRepository contractRepository;
    private final SowingAdvisoryLogRepository advisoryLogRepository;
    private final ProcurementRecordRepository procurementRecordRepository;
    private final PaymentMilestoneRepository paymentMilestoneRepository;
    private final AgentActionLogRepository agentActionLogRepository;

    @Transactional(readOnly = true)
    public DashboardSummaryDTO getDashboardSummary() {
        List<Contract> contracts = contractRepository.findAll();

        long totalContracts = contracts.size();
        long activeContracts = contracts.stream().filter(c -> c.getStatus() == ContractStatus.ACTIVE).count();
        long atRiskContracts = contracts.stream().filter(c -> c.getStatus() == ContractStatus.AT_RISK).count();
        long delayedContracts = contracts.stream().filter(c -> c.getStatus() == ContractStatus.DELAYED).count();
        long completedContracts = contracts.stream().filter(c -> c.getStatus() == ContractStatus.COMPLETED).count();

        // Sowing Compliance Rate
        long compliantLogs = advisoryLogRepository.countByComplianceStatus(ComplianceStatus.COMPLIANT);
        long totalLogs = advisoryLogRepository.count();
        double sowingComplianceRate = totalLogs > 0 ?
                Math.round((compliantLogs * 1000.0) / totalLogs) / 10.0 : 100.0;

        // Yield Reconciliation
        BigDecimal totalExpectedYield = contracts.stream()
                .map(Contract::getExpectedYieldTons)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalDeliveredYield = procurementRecordRepository.sumTotalDeliveredTons();
        if (totalDeliveredYield == null) totalDeliveredYield = BigDecimal.ZERO;

        double yieldFulfillmentRate = totalExpectedYield.compareTo(BigDecimal.ZERO) > 0 ?
                Math.round((totalDeliveredYield.doubleValue() / totalExpectedYield.doubleValue()) * 1000.0) / 10.0 : 0.0;

        // Payments
        BigDecimal eligiblePayments = paymentMilestoneRepository.sumAmountByStatus(MilestoneStatus.ELIGIBLE);
        if (eligiblePayments == null) eligiblePayments = BigDecimal.ZERO;

        BigDecimal approvedPayments = paymentMilestoneRepository.sumAmountByStatus(MilestoneStatus.APPROVED);
        BigDecimal paidPayments = paymentMilestoneRepository.sumAmountByStatus(MilestoneStatus.PAID);
        BigDecimal disbursedPayments = (approvedPayments != null ? approvedPayments : BigDecimal.ZERO)
                .add(paidPayments != null ? paidPayments : BigDecimal.ZERO);

        long pendingApprovalCount = paymentMilestoneRepository.findByStatus(MilestoneStatus.ELIGIBLE).size();

        // Crop Yield Distribution (Committed vs Delivered)
        Map<String, List<Contract>> contractsByCrop = contracts.stream()
                .collect(Collectors.groupingBy(Contract::getCropType));

        List<DashboardSummaryDTO.CropYieldSummaryDTO> cropBreakdown = new ArrayList<>();
        for (Map.Entry<String, List<Contract>> entry : contractsByCrop.entrySet()) {
            String crop = entry.getKey();
            BigDecimal committed = entry.getValue().stream()
                    .map(Contract::getExpectedYieldTons)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal delivered = BigDecimal.ZERO;
            for (Contract c : entry.getValue()) {
                BigDecimal cd = procurementRecordRepository.sumDeliveredTonsByContractId(c.getId());
                if (cd != null) {
                    delivered = delivered.add(cd);
                }
            }

            double percent = committed.compareTo(BigDecimal.ZERO) > 0 ?
                    Math.round((delivered.doubleValue() / committed.doubleValue()) * 1000.0) / 10.0 : 0.0;

            cropBreakdown.add(DashboardSummaryDTO.CropYieldSummaryDTO.builder()
                    .crop(crop)
                    .committedTons(committed)
                    .deliveredTons(delivered)
                    .fulfillmentPercent(percent)
                    .build());
        }

        // Status Breakdown
        Map<String, Long> statusBreakdown = new LinkedHashMap<>();
        statusBreakdown.put("ACTIVE", activeContracts);
        statusBreakdown.put("AT_RISK", atRiskContracts);
        statusBreakdown.put("DELAYED", delayedContracts);
        statusBreakdown.put("COMPLETED", completedContracts);

        // Recent Agent Logs
        List<AgentActionLog> recentLogs = agentActionLogRepository.findTop20ByOrderByTimestampDesc();

        return DashboardSummaryDTO.builder()
                .totalContracts(totalContracts)
                .activeContracts(activeContracts)
                .atRiskContracts(atRiskContracts)
                .delayedContracts(delayedContracts)
                .completedContracts(completedContracts)
                .sowingComplianceRate(sowingComplianceRate)
                .totalExpectedYieldTons(totalExpectedYield)
                .totalDeliveredTons(totalDeliveredYield)
                .yieldFulfillmentRate(yieldFulfillmentRate)
                .eligiblePaymentsAmount(eligiblePayments)
                .disbursedPaymentsAmount(disbursedPayments)
                .pendingApprovalMilestonesCount(pendingApprovalCount)
                .cropYieldBreakdown(cropBreakdown)
                .statusBreakdown(statusBreakdown)
                .recentAgentLogs(recentLogs)
                .build();
    }
}
