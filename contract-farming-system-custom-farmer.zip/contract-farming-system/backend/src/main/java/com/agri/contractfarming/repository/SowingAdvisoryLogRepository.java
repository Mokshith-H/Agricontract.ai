package com.agri.contractfarming.repository;

import com.agri.contractfarming.model.ComplianceStatus;
import com.agri.contractfarming.model.SowingAdvisoryLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SowingAdvisoryLogRepository extends JpaRepository<SowingAdvisoryLog, Long> {
    List<SowingAdvisoryLog> findByContractId(Long contractId);
    List<SowingAdvisoryLog> findByComplianceStatus(ComplianceStatus status);
    long countByComplianceStatus(ComplianceStatus status);
}
