package com.agri.contractfarming.service;

import com.agri.contractfarming.dto.ContractCreateRequestDTO;
import com.agri.contractfarming.dto.ContractDetailDTO;
import com.agri.contractfarming.model.*;
import com.agri.contractfarming.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ContractService {

    private final ContractRepository contractRepository;
    private final FarmerRepository farmerRepository;
    private final SowingAdvisoryLogRepository advisoryLogRepository;
    private final FieldVisitRepository fieldVisitRepository;
    private final ProcurementRecordRepository procurementRecordRepository;
    private final PaymentMilestoneRepository paymentMilestoneRepository;
    private final AgentActionLogRepository agentActionLogRepository;

    public List<Contract> getAllContracts() {
        return contractRepository.findAll();
    }

    public Contract getContractById(Long id) {
        return contractRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Contract not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public ContractDetailDTO getContractDetails(Long id) {
        Contract contract = getContractById(id);
        List<SowingAdvisoryLog> advisories = advisoryLogRepository.findByContractId(id);
        List<FieldVisit> visits = fieldVisitRepository.findByContractIdOrderByVisitDateDesc(id);
        List<ProcurementRecord> procurements = procurementRecordRepository.findByContractIdOrderByDeliveryDateDesc(id);
        List<PaymentMilestone> milestones = paymentMilestoneRepository.findByContractId(id);
        List<AgentActionLog> logs = agentActionLogRepository.findByContractCodeOrderByTimestampDesc(contract.getContractCode());

        BigDecimal deliveredTons = procurementRecordRepository.sumDeliveredTonsByContractId(id);
        if (deliveredTons == null) deliveredTons = BigDecimal.ZERO;

        BigDecimal totalContractValue = contract.getExpectedYieldTons()
                .multiply(contract.getPricePerTon());

        // Determine 5-stage lifecycle stepper:
        // 1: Signed, 2: Sowing Verified, 3: Advisory Compliant, 4: Harvest Delivered, 5: Settled
        int stage = 1;
        String stageName = "Contract Signed & Onboarded";

        boolean sowingPassed = advisories.stream().anyMatch(a ->
                a.getStage() == AdvisoryStage.SOWING && a.getComplianceStatus() == ComplianceStatus.COMPLIANT);
        if (sowingPassed) {
            stage = 2;
            stageName = "Sowing Verified";
        }

        boolean postSowingPassed = advisories.stream().anyMatch(a ->
                (a.getStage() == AdvisoryStage.FERTILIZER || a.getStage() == AdvisoryStage.PEST_CONTROL)
                        && a.getComplianceStatus() == ComplianceStatus.COMPLIANT);
        if (sowingPassed && postSowingPassed) {
            stage = 3;
            stageName = "Advisory Compliant (Growing Phase)";
        }

        if (deliveredTons.compareTo(BigDecimal.ZERO) > 0) {
            stage = 4;
            stageName = "Harvest Delivered (" + deliveredTons + " Tons)";
        }

        boolean allPaid = !milestones.isEmpty() && milestones.stream().allMatch(m ->
                m.getStatus() == MilestoneStatus.APPROVED || m.getStatus() == MilestoneStatus.PAID);
        if (stage == 4 && (allPaid || contract.getStatus() == ContractStatus.COMPLETED)) {
            stage = 5;
            stageName = "Payment Settled & Contract Fulfilled";
        }

        // Generate AI risk notes
        String aiRiskNotes = "Agronomic risk index is NORMAL. Field visits indicate healthy vegetative vigor.";
        if (contract.getStatus() == ContractStatus.AT_RISK) {
            boolean pestAlert = visits.stream().anyMatch(FieldVisit::getPestAlert);
            aiRiskNotes = pestAlert ?
                    "FLAGGED CRITICAL: Pest alert reported by field officer. Emergency advisory triggered." :
                    "FLAGGED AT_RISK: Overdue compliance or low vigor scores detected by AI Auditor.";
        } else if (contract.getStatus() == ContractStatus.COMPLETED) {
            aiRiskNotes = "Contract execution fully completed. All deliveries audited and reconciled.";
        }

        // Map cleanly to DTOs without circular dependencies
        List<ContractDetailDTO.AdvisoryLogItemDTO> advisoryDTOs = advisories.stream()
                .map(a -> ContractDetailDTO.AdvisoryLogItemDTO.builder()
                        .id(a.getId())
                        .stage(a.getStage())
                        .scheduledDate(a.getScheduledDate())
                        .actualDate(a.getActualDate())
                        .advisoryText(a.getAdvisoryText())
                        .complianceStatus(a.getComplianceStatus())
                        .build())
                .collect(Collectors.toList());

        List<ContractDetailDTO.FieldVisitItemDTO> visitDTOs = visits.stream()
                .map(v -> ContractDetailDTO.FieldVisitItemDTO.builder()
                        .id(v.getId())
                        .officerName(v.getOfficerName())
                        .visitDate(v.getVisitDate())
                        .cropHealthScore(v.getCropHealthScore())
                        .pestAlert(v.getPestAlert())
                        .soilMoisture(v.getSoilMoisture())
                        .remarks(v.getRemarks())
                        .build())
                .collect(Collectors.toList());

        List<ContractDetailDTO.ProcurementItemDTO> procurementDTOs = procurements.stream()
                .map(p -> ContractDetailDTO.ProcurementItemDTO.builder()
                        .id(p.getId())
                        .deliveryDate(p.getDeliveryDate())
                        .deliveredTons(p.getDeliveredTons())
                        .qualityGrade(p.getQualityGrade())
                        .receiptNumber(p.getReceiptNumber())
                        .payoutAmount(p.getPayoutAmount() != null ? p.getPayoutAmount() : 
                                (contract.getPricePerTon() != null ? p.getDeliveredTons().multiply(contract.getPricePerTon()) : BigDecimal.ZERO))
                        .build())
                .collect(Collectors.toList());

        List<ContractDetailDTO.PaymentMilestoneItemDTO> milestoneDTOs = milestones.stream()
                .map(m -> ContractDetailDTO.PaymentMilestoneItemDTO.builder()
                        .id(m.getId())
                        .milestoneTitle(m.getMilestoneTitle())
                        .amount(m.getAmount())
                        .triggerCondition(m.getTriggerCondition())
                        .status(m.getStatus())
                        .updatedAt(m.getUpdatedAt())
                        .build())
                .collect(Collectors.toList());

        List<ContractDetailDTO.AgentLogItemDTO> logDTOs = logs.stream()
                .map(l -> ContractDetailDTO.AgentLogItemDTO.builder()
                        .id(l.getId())
                        .contractCode(l.getContractCode())
                        .agentName(l.getAgentName())
                        .actionType(l.getActionType())
                        .reasoning(l.getReasoning())
                        .severity(l.getSeverity())
                        .timestamp(l.getTimestamp())
                        .build())
                .collect(Collectors.toList());

        return ContractDetailDTO.builder()
                .id(contract.getId())
                .contractCode(contract.getContractCode())
                .farmerId(contract.getFarmer().getId())
                .farmerName(contract.getFarmer().getName())
                .farmerPhone(contract.getFarmer().getPhone())
                .farmerVillage(contract.getFarmer().getVillage())
                .farmerDistrict(contract.getFarmer().getDistrict())
                .kycVerified(contract.getFarmer().getKycVerified())
                .cropType(contract.getCropType())
                .variety(contract.getVariety())
                .committedAcreage(contract.getCommittedAcreage())
                .expectedYieldTons(contract.getExpectedYieldTons())
                .deliveredYieldTons(deliveredTons)
                .pricePerTon(contract.getPricePerTon())
                .totalContractValue(totalContractValue)
                .sowingStartDate(contract.getSowingStartDate())
                .sowingEndDate(contract.getSowingEndDate())
                .expectedHarvestDate(contract.getExpectedHarvestDate())
                .status(contract.getStatus())
                .lifecycleStage(stage)
                .lifecycleStageName(stageName)
                .aiRiskNotes(aiRiskNotes)
                .advisoryLogs(advisoryDTOs)
                .fieldVisits(visitDTOs)
                .procurementRecords(procurementDTOs)
                .paymentMilestones(milestoneDTOs)
                .agentLogs(logDTOs)
                .build();
    }

    @Transactional
    public Contract createContract(ContractCreateRequestDTO dto) {
        Farmer farmer = farmerRepository.findById(dto.getFarmerId())
                .orElseThrow(() -> new RuntimeException("Farmer not found with id: " + dto.getFarmerId()));

        String contractCode = "AGRI-" + dto.getCropType().toUpperCase().substring(0, Math.min(3, dto.getCropType().length()))
                + "-" + (1000 + contractRepository.count() + 1);

        Contract contract = Contract.builder()
                .contractCode(contractCode)
                .farmer(farmer)
                .cropType(dto.getCropType())
                .variety(dto.getVariety())
                .committedAcreage(dto.getCommittedAcreage())
                .expectedYieldTons(dto.getExpectedYieldTons())
                .pricePerTon(dto.getPricePerTon())
                .sowingStartDate(dto.getSowingStartDate())
                .sowingEndDate(dto.getSowingEndDate())
                .expectedHarvestDate(dto.getExpectedHarvestDate())
                .status(ContractStatus.ACTIVE)
                .build();

        Contract saved = contractRepository.save(contract);

        // Auto-seed initial Sowing Advisory Log
        SowingAdvisoryLog prepLog = SowingAdvisoryLog.builder()
                .contract(saved)
                .stage(AdvisoryStage.LAND_PREP)
                .scheduledDate(dto.getSowingStartDate().minusDays(5))
                .actualDate(dto.getSowingStartDate().minusDays(5))
                .advisoryText("Deep tillage, weed clearance, and application of farmyard manure (FYM) completed.")
                .complianceStatus(ComplianceStatus.COMPLIANT)
                .build();
        advisoryLogRepository.save(prepLog);

        SowingAdvisoryLog sowingLog = SowingAdvisoryLog.builder()
                .contract(saved)
                .stage(AdvisoryStage.SOWING)
                .scheduledDate(dto.getSowingStartDate().plusDays(2))
                .advisoryText("Seed treatment with Trichoderma & Rhizobium; maintain recommended row spacing.")
                .complianceStatus(ComplianceStatus.PENDING)
                .build();
        advisoryLogRepository.save(sowingLog);

        // Auto-seed payment milestones (Stage 1 Mobilization, Stage 2 Mid-Growth, Stage 3 Final Delivery)
        BigDecimal totalVal = dto.getExpectedYieldTons().multiply(dto.getPricePerTon());
        BigDecimal m1Amount = totalVal.multiply(new BigDecimal("0.20"));
        BigDecimal m2Amount = totalVal.multiply(new BigDecimal("0.30"));
        BigDecimal m3Amount = totalVal.multiply(new BigDecimal("0.50"));

        PaymentMilestone m1 = PaymentMilestone.builder()
                .contract(saved)
                .milestoneTitle("Stage 1: Sowing & Mobilization Advance")
                .amount(m1Amount)
                .triggerCondition("Sowing verification and Land Prep compliance")
                .status(MilestoneStatus.LOCKED)
                .updatedAt(LocalDateTime.now())
                .build();
        PaymentMilestone m2 = PaymentMilestone.builder()
                .contract(saved)
                .milestoneTitle("Stage 2: Mid-Growth Agronomic Compliance")
                .amount(m2Amount)
                .triggerCondition("Field visit score >= 7 and fertilizer compliance")
                .status(MilestoneStatus.LOCKED)
                .updatedAt(LocalDateTime.now())
                .build();
        PaymentMilestone m3 = PaymentMilestone.builder()
                .contract(saved)
                .milestoneTitle("Stage 3: Final Harvest Delivery & Quality Reconcile")
                .amount(m3Amount)
                .triggerCondition("Procurement 100% target verified with Grade A/B")
                .status(MilestoneStatus.LOCKED)
                .updatedAt(LocalDateTime.now())
                .build();

        paymentMilestoneRepository.saveAll(List.of(m1, m2, m3));

        // Create Agent Action Log
        AgentActionLog log = AgentActionLog.builder()
                .contractCode(saved.getContractCode())
                .agentName("Contract Lifecycle Orchestrator")
                .actionType("CONTRACT_ONBOARDED")
                .reasoning("New contract initialized with farmer " + farmer.getName() + " for " + dto.getCommittedAcreage() + " acres. Initial milestones & advisory schedule established.")
                .severity(LogSeverity.INFO)
                .timestamp(LocalDateTime.now())
                .build();
        agentActionLogRepository.save(log);

        return saved;
    }

    @Transactional
    public Contract updateContract(Long id, Contract updated) {
        Contract existing = getContractById(id);
        existing.setStatus(updated.getStatus());
        existing.setExpectedHarvestDate(updated.getExpectedHarvestDate());
        existing.setPricePerTon(updated.getPricePerTon());
        return contractRepository.save(existing);
    }
}
