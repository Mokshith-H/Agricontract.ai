package com.agri.contractfarming.model;

public enum LogSeverity {
    INFO,
    WARNING,
    CRITICAL
}
