package com.agri.contractfarming.controller;

import com.agri.contractfarming.dto.ProcurementRequestDTO;
import com.agri.contractfarming.model.ProcurementRecord;
import com.agri.contractfarming.service.ProcurementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/procurement")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ProcurementController {

    private final ProcurementService procurementService;

    @GetMapping
    public ResponseEntity<List<ProcurementRecord>> getAllProcurements() {
        return ResponseEntity.ok(procurementService.getAllProcurements());
    }

    @GetMapping("/contract/{contractId}")
    public ResponseEntity<List<ProcurementRecord>> getProcurementsByContract(@PathVariable Long contractId) {
        return ResponseEntity.ok(procurementService.getProcurementsByContract(contractId));
    }

    @PostMapping
    public ResponseEntity<ProcurementRecord> recordProcurement(@Valid @RequestBody ProcurementRequestDTO dto) {
        return new ResponseEntity<>(procurementService.recordProcurement(dto), HttpStatus.CREATED);
    }
}
