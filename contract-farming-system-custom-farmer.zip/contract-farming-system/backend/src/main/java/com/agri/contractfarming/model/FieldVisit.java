package com.agri.contractfarming.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "field_visits")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class FieldVisit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "contract_id", nullable = false)
    @JsonIgnoreProperties({"advisoryLogs", "fieldVisits", "procurementRecords", "paymentMilestones", "hibernateLazyInitializer", "handler"})
    private Contract contract;

    @Column(nullable = false)
    private String officerName;

    @Column(nullable = false)
    private LocalDate visitDate;

    @Column(nullable = false)
    private Integer cropHealthScore; // 1-10

    @Column(nullable = false)
    private Boolean pestAlert;

    @Column(nullable = false)
    private String soilMoisture;

    @Column(length = 1000)
    private String remarks;
}
