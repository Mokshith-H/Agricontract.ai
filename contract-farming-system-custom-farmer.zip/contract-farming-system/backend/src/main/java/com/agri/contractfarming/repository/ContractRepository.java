package com.agri.contractfarming.repository;

import com.agri.contractfarming.model.Contract;
import com.agri.contractfarming.model.ContractStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ContractRepository extends JpaRepository<Contract, Long> {
    Optional<Contract> findByContractCode(String contractCode);
    List<Contract> findByStatus(ContractStatus status);
    List<Contract> findByFarmerId(Long farmerId);

    @Query("SELECT c FROM Contract c LEFT JOIN FETCH c.advisoryLogs LEFT JOIN FETCH c.fieldVisits WHERE c.id = :id")
    Optional<Contract> findByIdWithDetails(Long id);
}
