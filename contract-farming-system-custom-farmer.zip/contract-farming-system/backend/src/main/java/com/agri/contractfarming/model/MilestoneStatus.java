package com.agri.contractfarming.model;

public enum MilestoneStatus {
    LOCKED,
    ELIGIBLE,
    APPROVED,
    PAID
}
