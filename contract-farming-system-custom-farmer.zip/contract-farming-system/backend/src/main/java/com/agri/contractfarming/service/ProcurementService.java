package com.agri.contractfarming.service;

import com.agri.contractfarming.dto.ProcurementRequestDTO;
import com.agri.contractfarming.model.Contract;
import com.agri.contractfarming.model.ProcurementRecord;
import com.agri.contractfarming.repository.ContractRepository;
import com.agri.contractfarming.repository.ProcurementRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProcurementService {

    private final ProcurementRecordRepository procurementRecordRepository;
    private final ContractRepository contractRepository;
    private final ContractAgentService agentService;

    public List<ProcurementRecord> getAllProcurements() {
        return procurementRecordRepository.findAllByOrderByDeliveryDateDesc();
    }

    public List<ProcurementRecord> getProcurementsByContract(Long contractId) {
        return procurementRecordRepository.findByContractIdOrderByDeliveryDateDesc(contractId);
    }

    @Transactional
    public ProcurementRecord recordProcurement(ProcurementRequestDTO dto) {
        Contract contract = contractRepository.findById(dto.getContractId())
                .orElseThrow(() -> new RuntimeException("Contract not found with id: " + dto.getContractId()));

        String receiptNumber = dto.getReceiptNumber();
        if (receiptNumber == null || receiptNumber.isBlank()) {
            receiptNumber = "RCPT-" + contract.getCropType().toUpperCase().substring(0, Math.min(3, contract.getCropType().length()))
                    + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        }

        BigDecimal payout = dto.getPayoutAmount();
        if (payout == null && contract.getPricePerTon() != null) {
            payout = dto.getDeliveredTons().multiply(contract.getPricePerTon());
        }

        ProcurementRecord record = ProcurementRecord.builder()
                .contract(contract)
                .deliveryDate(dto.getDeliveryDate())
                .deliveredTons(dto.getDeliveredTons())
                .qualityGrade(dto.getQualityGrade())
                .receiptNumber(receiptNumber)
                .payoutAmount(payout)
                .build();

        ProcurementRecord saved = procurementRecordRepository.save(record);

        // Autonomous trigger: Procurement & Milestone Agent reconciles yields and unlocks payment milestones
        agentService.evaluateProcurement(saved);

        return saved;
    }
}
