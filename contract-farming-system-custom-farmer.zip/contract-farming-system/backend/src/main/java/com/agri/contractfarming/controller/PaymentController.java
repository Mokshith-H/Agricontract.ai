package com.agri.contractfarming.controller;

import com.agri.contractfarming.model.PaymentMilestone;
import com.agri.contractfarming.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class PaymentController {

    private final PaymentService paymentService;

    @GetMapping
    public ResponseEntity<List<PaymentMilestone>> getAllPayments() {
        return ResponseEntity.ok(paymentService.getAllPayments());
    }

    @GetMapping("/contract/{contractId}")
    public ResponseEntity<List<PaymentMilestone>> getPaymentsByContract(@PathVariable Long contractId) {
        return ResponseEntity.ok(paymentService.getPaymentsByContract(contractId));
    }

    @PatchMapping("/{id}/unlock")
    public ResponseEntity<PaymentMilestone> unlockPayment(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.unlockPayment(id));
    }

    @PatchMapping("/{id}/approve")
    public ResponseEntity<PaymentMilestone> approvePayment(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.approvePayment(id));
    }

    @PatchMapping("/{id}/pay")
    public ResponseEntity<PaymentMilestone> markAsPaid(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.markAsPaid(id));
    }
}
