package com.agri.contractfarming.model;

public enum ComplianceStatus {
    PENDING,
    COMPLIANT,
    DELAYED,
    NON_COMPLIANT
}
