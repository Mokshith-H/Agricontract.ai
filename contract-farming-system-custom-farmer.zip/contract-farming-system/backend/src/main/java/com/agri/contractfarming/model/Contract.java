package com.agri.contractfarming.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "contracts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Contract {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String contractCode;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "farmer_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Farmer farmer;

    @Column(nullable = false)
    private String cropType;

    @Column(nullable = false)
    private String variety;

    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal committedAcreage;

    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal expectedYieldTons;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal pricePerTon;

    @Column(nullable = false)
    private LocalDate sowingStartDate;

    @Column(nullable = false)
    private LocalDate sowingEndDate;

    @Column(nullable = false)
    private LocalDate expectedHarvestDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ContractStatus status;

    @OneToMany(mappedBy = "contract", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties({"contract", "hibernateLazyInitializer", "handler"})
    @Builder.Default
    private List<SowingAdvisoryLog> advisoryLogs = new ArrayList<>();

    @OneToMany(mappedBy = "contract", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties({"contract", "hibernateLazyInitializer", "handler"})
    @Builder.Default
    private List<FieldVisit> fieldVisits = new ArrayList<>();

    @OneToMany(mappedBy = "contract", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties({"contract", "hibernateLazyInitializer", "handler"})
    @Builder.Default
    private List<ProcurementRecord> procurementRecords = new ArrayList<>();

    @OneToMany(mappedBy = "contract", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties({"contract", "hibernateLazyInitializer", "handler"})
    @Builder.Default
    private List<PaymentMilestone> paymentMilestones = new ArrayList<>();
}
