package com.agri.contractfarming.repository;

import com.agri.contractfarming.model.AgentActionLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentActionLogRepository extends JpaRepository<AgentActionLog, Long> {
    List<AgentActionLog> findTop20ByOrderByTimestampDesc();
    List<AgentActionLog> findByContractCodeOrderByTimestampDesc(String contractCode);
}
