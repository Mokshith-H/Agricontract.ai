# 🌾 AgriContract AI — Contract-Farming Agentic Platform (PS225)

An autonomous **Contract-Farming Agentic AI System & Progress Dashboard** for Farmer Relations. Autonomously tracks farmer agreements, sowing windows, agronomic advisory compliance, field inspections, harvest weighbridge deliveries, and automated milestone payouts.

---

## Quick Start (Windows, macOS, and Linux)

### Prerequisites
1. **Java Development Kit (JDK) 21 or newer**
2. **Node.js 18 or newer** (includes npm)
3. An internet connection on first run to download Maven and npm dependencies
4. Ports **8080** and **5173** available

Extract the ZIP file, then launch from the extracted project folder:

- **Windows:** Double-click `start-all.bat`
- **macOS/Linux:** Open a terminal in the folder and run `bash ./start-all.sh`

The launcher waits for both services to respond, then opens
`http://localhost:5173` in your default browser. On Windows, it opens separate
terminal windows for the backend and frontend. On macOS/Linux, both run from
the terminal where you launched the script. Keep the terminals open while
using the app; close them or press `Ctrl+C` to stop. If automatic browser
opening is unavailable, open the URL above manually.

On the first run, Maven and npm download their dependencies. The ZIP intentionally
does not include OS-specific `node_modules` or generated build output.

### Troubleshooting

- Check `java -version`, `node --version`, and `npm --version` in a terminal.
  Install JDK 21+ and Node.js 18+ if they are missing.
- If startup reports a port conflict, stop the other application using port
  8080 or 5173 and try again.
- The database is in memory; sample data is recreated when the backend starts.
- VS Code and its Java extension are optional; the launchers work without them.

## URLs & Endpoints

| Service | URL | Description |
| :--- | :--- | :--- |
| **Frontend Application** | `http://localhost:5173` | Progress Dashboard, Contracts, Visits, Procurement, AI Copilot |
| **Backend API Summary** | `http://localhost:8080/api/dashboard/summary` | Real-time KPIs, Yield Reconciliation & Agent Logs |
| **H2 Database Console** | `http://localhost:8080/h2-console` | In-memory DB viewer (`JDBC URL: jdbc:h2:mem:contract_farming_db`, User: `sa`, Password: *empty*) |

---

## 🏗️ Project Architecture

```
contract-farming-system/
├── .vscode/                     # VS Code launch configurations, tasks, and recommended extensions
├── backend/                     # Spring Boot 3 (Maven, Java 21, JPA, H2, REST)
│   ├── mvnw & mvnw.cmd          # Maven Wrapper for zero-setup execution
│   ├── pom.xml
│   └── src/main/java/com/agri/contractfarming/
│       ├── config/              # WebConfig (CORS), DataSeeder (10 contracts, 10 visits, 5 deliveries)
│       ├── controller/          # REST Controllers for Dashboard, Contracts, Visits, Procurement, Payments, Copilot
│       ├── dto/                 # Clean decoupled DTOs (ContractDetailDTO, Requests, Summaries)
│       ├── model/               # JPA Entities (Farmer, Contract, SowingAdvisory, FieldVisit, Procurement, Payment, Log)
│       ├── repository/          # Spring Data JPA Repositories
│       └── service/             # Agentic AI Engine (ContractAgentService), ContractService, PaymentService, etc.
├── frontend/                    # React 18 + Vite + Recharts + Lucide Icons
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── components/          # Dashboard, Stepper Modal, Field Visits Form, Procurement Calculator, Copilot
│       ├── api.js               # Axios REST client
│       ├── index.css            # Agri-Tech design system with keyboard accessibility
│       ├── Dashboard.css
│       ├── Contracts.css
│       └── Modals.css
├── start-all.bat                # 1-Click Windows Launcher for both services
├── start-backend.bat
├── start-frontend.bat
├── start-all.sh                 # 1-Click Linux/macOS Launcher
└── README.md
```

---

## 🤖 Core Agentic AI Capabilities

1. **Sowing & Compliance Auditor:** Automatically monitors sowing timelines and field visit scores (`health < 6` or `pestAlert == true` flags `AT_RISK` and issues agronomic advisories).
2. **Procurement & Yield Reconciler:** Compares incoming harvest truckload deliveries against contractual commitments and calculates real-time fulfillment percentages.
3. **Automated Payment Trigger:** Unlocks milestones (`LOCKED` → `ELIGIBLE`) when sowing or delivery thresholds are met, feeding the one-click **Milestone Payout Queue**.
4. **Natural Language Agricultural Copilot:** Answers farmer relations queries using live database context (fallback rule engine works out-of-the-box even without an external API key; supports optional `OPENAI_API_KEY` or `GEMINI_API_KEY`).
