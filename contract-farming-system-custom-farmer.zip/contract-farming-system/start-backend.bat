@echo off
title AgriContract AI - Backend
cd /d "%~dp0backend"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" goto java_ready
set "JAVA_HOME="
where java >nul 2>nul
if errorlevel 1 (
    echo Java 21 or newer is required. Install a JDK and add java to PATH.
    pause
    exit /b 1
)
:java_ready
mvnw.cmd spring-boot:run
pause
