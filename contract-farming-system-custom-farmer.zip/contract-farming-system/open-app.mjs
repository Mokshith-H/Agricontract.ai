import { spawn, spawnSync } from 'node:child_process';

const appUrl = 'http://localhost:5173';
const checks = [
  ['frontend', appUrl],
  ['backend', 'http://localhost:8080/api/dashboard/summary']
];
const timeoutAt = Date.now() + 5 * 60 * 1000;
let lastStatus = 'services are still starting';
let ready = false;

async function checkService(name, url) {
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(2000) });
    return response.ok ? null : `${name} returned HTTP ${response.status}`;
  } catch (error) {
    return `${name} is not ready (${error.message})`;
  }
}

while (Date.now() < timeoutAt) {
  const statuses = (await Promise.all(checks.map(([name, url]) => checkService(name, url))))
    .filter(Boolean);
  if (statuses.length === 0) {
    ready = true;
    break;
  }

  lastStatus = statuses.join('; ');
  await new Promise((resolve) => setTimeout(resolve, 1000));
}

if (!ready) {
  console.error(`The app did not become ready within five minutes: ${lastStatus}`);
  console.error(`Check the startup terminals, then open ${appUrl} manually.`);
  process.exitCode = 1;
} else {
  let command;
  let args;

  if (process.platform === 'win32') {
    command = 'cmd.exe';
    args = ['/c', 'start', '', appUrl];
  } else if (process.platform === 'darwin') {
    command = 'open';
    args = [appUrl];
  } else {
    command = 'xdg-open';
    args = [appUrl];
    if (spawnSync('which', [command], { stdio: 'ignore' }).status !== 0) {
      console.error(`App is ready. Open ${appUrl} in your browser.`);
      process.exit(0);
    }
  }

  const browser = spawn(command, args, {
    detached: true,
    stdio: 'ignore',
    windowsHide: true
  });

  browser.once('error', (error) => {
    console.error(`App is ready, but the browser could not be opened: ${error.message}`);
    console.error(`Open ${appUrl} in your browser.`);
  });
  browser.once('spawn', () => {
    browser.unref();
    console.log(`App is ready. Opening ${appUrl}`);
  });
}
