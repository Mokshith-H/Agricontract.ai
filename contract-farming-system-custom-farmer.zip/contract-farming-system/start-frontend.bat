@echo off
title AgriContract AI - Frontend
cd /d "%~dp0frontend"
where npm >nul 2>nul
if errorlevel 1 (
    echo Node.js 18 or newer, including npm, is required. Install Node.js and add it to PATH.
    pause
    exit /b 1
)
if not exist node_modules (
    echo Installing npm dependencies...
    npm ci
)
npm run dev
pause
